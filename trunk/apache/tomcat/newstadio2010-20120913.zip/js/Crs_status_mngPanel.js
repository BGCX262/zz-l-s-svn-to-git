// 显示历史学生成绩等

zz.Office.Crs_status_mngPanel = function(config) {
	zz.Office.Crs_status_mngPanel.superclass.constructor.call(this, config);

/**
 * 
 */

	var proxy = new Ext.data.HttpProxy({
				url : 'getstudentlist.do?tab=crs_status_mng'
			});
			//"sid":"19951142","sex":"男","ename":"Kim Yu Hwan","pb_id":"GG0281258","pw":"","kname":"김유환","cname":"金裕煥"
			//"t0601":"-","t0702":"基本课程","t0701":"-","t0902":"-","t0901":"-","t0502":"-","t0602":"-",
			//"t1002":"-","t0802":"-","t0801":"-","t1001":"-",
	var rcdarr = [{
		//需要动态添加年份，
				name : "id",
				type : "string"
			}, {
				name : "sex",
				type : "string"
			}, {
				name : "ename",
				type : "string"
			}, {
				name : "sid",
				type : "string"
			}, {
				name : "cname",
				type : "string"
			}, {
				name : "kname",
				type : "string"
			}, {
				name : "pb_id",
				type : "string"
			}];
			
	// 按当前年份生成0502-至今的学期数组
	var years = 2006;
	var yeararr = [];//[{name : "t0502",type : "string"}];
	var d = new Date().getFullYear();
	do{
		var yy = d.toString().substring(2,4);
		var arr2 = [{name : "t"+yy+"02",type : "string"},{name : "t"+yy+"01",type : "string"}];
		yeararr = yeararr.concat(arr2);
	}while(d-- > years);
	yeararr = yeararr.concat([{name : "t0502",type : "string"}]);
	
	
	var recordType = new Ext.data.Record.create(rcdarr.concat(yeararr));

	// 定义分析器
	var reader = new Ext.data.JsonReader({
				totalProperty : "results",
				root : "rows",
				id : "id"
			}, recordType);

	// 定义store
	/*var dsgrid = new Ext.data.Store({
				id : 'dsgrid_pi',
				proxy : proxy,
				reader : reader		
	});*/
	var ds = new Ext.data.Store({
				id : 'dss_pi',
				proxy : proxy,
				reader : reader
			});

	//var fsw = 0;	//发送请求计数
	ds.on('load', function(elstore) {
				var d = Ext.getCmp('cosmenu_csm');
				if (d.getText() != '全部') {
					ds.filter('course', d.getText());
				}
				
				//elstore.each(function(r) {
				//	dsgrid.add(r);
				//});
				
				//if(fsw++<=10){
				//	ds.load({params :{start:50+5*fsw, limit:55+5*fsw} })
				//}else fsw = 0;
					
			});
			
	var dssub = new Ext.data.JsonStore({
				fields : ['text', 'view'],
				url : 'getlist.do?par=term_cmbo&datecode=' + (new Date().getTime()),
				root : 'root',
				sortInfo : {
					field : "text",
					direction : "DESC"
				}
			});
	dssub.on('load', function(elstore) {
		elstore.each(function(r) {
			r.set('view', '20'+r.get('text')+'学期'); 
			});
		
		var el = Ext.getCmp('termcombo_csm');
			//el.expand( ) ;
			//el.select(elstore.getCount()-1);
		var r = new Ext.data.Record({text:"all", view:"全部"});
		elstore.add(r)
		//var r = elstore.getAt(0);
		el.setValue(r.get('view'));
			//ds.load({params :{term:r.get('text'),start:0, limit:10} });
		ds.load({params :{start:0, limit:100} });

	});
	this.ds = dssub;
	var cols = [new Ext.grid.RowNumberer(), {
							header : '学号',
							dataIndex : 'sid'
						}, {
							header : '中文名',
							dataIndex : 'cname'
						}, {
							header : '韩文名',
							dataIndex : 'kname'
						}, {
							header : '护照名',
							dataIndex : 'ename'
						}, {
							header : '性别',
							width : 15,
							dataIndex : 'sex'
						}];
	for(var i=0; i< yeararr.length; i++){
		cols = cols.concat([{header : yeararr[i].name.substring(1,yeararr[i].name.length),dataIndex : yeararr[i].name}]);
	}
	var cm = new Ext.grid.ColumnModel({
				defaultSortable : true,
				defaultWidth : 40,
				columns : cols
			});
	var exportbtn = new Ext.Button({
	    text: '&nbsp;导出Excel',
	    iconCls : 'excel',
	    handler: function() {
	        var vExportContent = grid.getExcelXml();
	        if (Ext.isIE || Ext.isSafari || Ext.isSafari2 || Ext.isSafari3) {
	            var fd=Ext.get('frmDummy');
	            if (!fd) {
	                fd=Ext.DomHelper.append(Ext.getBody(),{tag:'form',method:'post',id:'frmDummy',action:'exportexcel.jsp', target:'_blank',name:'frmDummy',cls:'x-hidden',cn:[
	                    {tag:'input',name:'exportContent',id:'exportContent',type:'hidden'}
	                ]},true);
	            }
	            fd.child('#exportContent').set({value:vExportContent});
	            fd.dom.submit();
	        } else {
	            document.location = 'data:application/vnd.ms-excel;base64,'+Base64.encode(vExportContent);
	        }}
	});
			
	var mytoolbar = new Ext.Toolbar([
			'','学期: ',{
				name : 'termcheck_csm',
				id : 'termcombo_csm',
				store : dssub,
				xtype : 'combo',
				mode : 'local',
				width : 100,
				triggerAction : 'all',
				// pageSize : 5, // 未实现分页，希望能按课程分页，第一页是当前cosname
				resizable : true,
				valueField : 'text',
				displayField : 'view',
				editable : false,
				listeners : {
					'select' : function(combo, record) {
						ds.load({params :{term:record.get('text')} });
						var el = Ext.getCmp('cosmenu_csm_all');
						el.handler();
						// Ext.getCmp('classel').text, record.get('text') );
					}
				}
				
				},'','-','',
			{
				id : 'cosmenu_csm',
				text : '全部',
				iconCls : 'im16x16',
				handler : function() {
					// putClassEl();
					if (!(this.text == '全部'))
						putClassEl();
					ds.clearFilter();
					fliterOptation(this.text, '全部班级');
				},
				xtype : 'splitbutton',
				menu : new Ext.menu.Menu({
							items : [{
								id : 'cosmenu_csm_all',
								text : '全部',
								iconCls : 'im16x16',
								handler : function() {
									putClassEl();
									var t = Ext.getCmp('termcombo_csm').getValue();
									fliterOptation(this.text, '全部班级',null,t);
									Ext.getCmp('cosmenu_csm').setText(this.text);
								}
							}, {
								text : '基本课程',
								iconCls : 'user-kid',
								handler : function() {
									putClassEl();
									var t = Ext.getCmp('termcombo_csm').getValue();
									fliterOptation(this.text, '全部班级',null,t);
									Ext.getCmp('cosmenu_csm').setText(this.text);
								}
							}, {
								text : '深化课程',
								iconCls : 'user-suit',
								handler : function() {
									putClassEl();
									var t = Ext.getCmp('termcombo_csm').getValue();
									fliterOptation(this.text, '全部班级',null,t);
									Ext.getCmp('cosmenu_csm').setText(this.text);

								}
							}, {
								text : '双学位课程',
								iconCls : 'user-girl',
								handler : function() {
									putClassEl();
									var t = Ext.getCmp('termcombo_csm').getValue();
									fliterOptation(this.text, '全部班级',null,t);
									Ext.getCmp('cosmenu_csm').setText(this.text);

								}
							}]
						})

			},
			'',
			'-',
			'',
			{
				id : 'classel_csm',
				text : '全部班级',
				iconCls : 'im16x16',
				hidden: true,
				handler : function() {
					var fls = this.text;
					fliterOptation(Ext.getCmp('cosmenu_csm').text, this.text);
				},
				xtype : 'splitbutton',
				menu : new Ext.menu.Menu({
							items : null
						}),
				listeners : {}
			},
			'',
			'-',
			'',
			'<img src=pic/s.gif style="background:url(images/find_user_icon.gif); width:16px" />',
			{
				width : 80,
				id : 'sidquery_csm',
				xtype : 'numberfield',
				emptyText : '输入学号...',
				// enableKeyEvents : true,
				listeners : {
					'blur' : function(el) {
						el.setValue('');
					},
					'render' : function(el1) {
						// el1.setValue('');
						Ext.get('sidquery_csm').on('keypress', function(e, el) {
							var querystr = 'sid';
							var k = e.getKey();
							if (k == 13) {
								ds.clearFilter()
								ds.filterBy(function(record) {
									var b = Ext.getCmp('cosmenu_csm').text
											.indexOf('全部') >= 0
											? true
											: Ext.getCmp('cosmenu_csm').text == record
													.get('course');
									b &= Ext.getCmp('classel_csm').text
											.indexOf('全部') >= 0
											? true
											: Ext.getCmp('classel_csm').text == record
													.get('iclass');
									return b
											&& record.get(querystr)
													.indexOf(el.value) > -1
								});
							}
						});

					}
				}
			}, '->',exportbtn,'', '']);
	// mytoolbar end

	var pagingBar = new Ext.PagingToolbar({
				disabled : false,
				pageSize : 100,
				store : ds,
				displayInfo : true,
				displayMsg : '共有 {2}条记录',
				// hidden : true,
				emptyMsg : "没有数据"
			});

	var grid = new Ext.grid.EditorGridPanel({
				id : 'datagrid_csm',
				cm : cm,
				store : ds,
				// width : 660,
				// height : 600,
				region : "center",
				margins : '2 2 2 2',
				selModel : new Ext.grid.RowSelectionModel({
					singleSelect:true,
					listeners : {
						'rowselect' : function(sm, row, rec) {
							setDetailsPanel(rec);
						}
					}
				}),
				bbar : pagingBar,
				stripeRows : true ,				
				viewConfig : {
				               forceFit : true,
				               getRowClass : function(record,rowIndex,rowParams,store){
				                   //签证快到期的红色显示
				               		/*var s = record.json.pb_begin!=null && record.json.pb_out!=null && record.json.pbtimeout!=null 
				               		? record.json.pbtimeout.replace(/-/g,"/") : null;
				               		var d = s != null ?Date.parse(s) : null;
				               		var to = 20*24*3600*1000;	//20天
				                   if(d!=null && (d-new Date().getTime())<to){
				                       return 'x-grid-record-red';
				                   }else{
				                       return '';
				                   } */    
				               }
				},
				loadMask : {
					msg : '正在载入数据,请稍等...'
				},
				// title : '公司列表',
				tbar : mytoolbar,
				listeners : {
					'render' : function(el) {
						// grid.on("afteredit", function(e) {
						// saveBtnHandler(null, e);
						// }, grid);
					},
					'beforerender' : function(gd) {
						// debugger;
					}
				}
			});

	function fliterOptation(cosname, classname, subjectstr,year) {
		// 使用fliteby的处理函数，处理班级课程间过滤联动关系,
		// 因为是单科成绩表，所以联动需加入subcombo的值
		ds.clearFilter();
		ds.filterBy(function(re) {
					var b = true;
					// 不能显示没有选课的人，考虑吧课程查询作为触发远程查询
					if (cosname.indexOf('全部') >= 0) { // 
						return b;
					} else if (classname.indexOf('全部') >= 0) { // 筛选class时，要考虑course的筛选继续有效
						b &= re.get('t'+year) == cosname;
					} else {
						b &= re.get('t'+year) == cosname;
						b &= re.get('iclass') == classname;
					}
					if (!(Ext.isEmpty(subjectstr)))
						b &= re.get('subname') == subjectstr
								|| Ext.isEmpty(re.get('subname'));
					return b;
				});
	}

	function putClassEl() {
		// 从grid store中提取班级
		Ext.getCmp('classel_csm').menu.removeAll();
		Ext.getCmp('classel_csm').menu.add({
					text : '全部班级',
					iconCls : 'im16x16',
					handler : function() {
						var s = this.text;
						fliterOptation(Ext.getCmp('cosmenu_csm').text, this.text);
						Ext.getCmp('classel_csm').setText(this.text);
					}
				});
		Ext.getCmp('classel_csm').setText('全部班级');
		var sz = '|';
		ds.data.each(function(re) {
					if (re.get('course') != Ext.getCmp('cosmenu_csm').getText())
						return;
					var c = re.get('iclass');
					if (c && c != '' && c != '-') {
						if (sz.indexOf('|' + c + '|') < 0) { // sz like
							// '|1-2|2-1|3-5|'
							sz += c + '|';
							var newclass = new Ext.menu.Item({
										text : c,
										iconCls : 'user-girl',
										handler : function() {
											fliterOptation(
													Ext.getCmp('cosmenu_csm').text,
													this.text);
											Ext.getCmp('classel_csm').setText(c);
										}
									});
							var m = Ext.getCmp('classel_csm').menu;
							// debugger
							m.add(newclass);
						}

					}
				});
		// 班级结束
	}

	function setDetailsPanel(record) {
		var dgrid = Ext.getCmp('detailsgrid');
		var cmde = new Ext.grid.ColumnModel({
					defaultWidth : 50,
					columns : [{
								header : '类    别',
								align : 'center',
								dataIndex : 'text'
							}, {
								header : '内    容',
								align : 'center',
								dataIndex : 'value'
							}]
				});
		// var outday = "";
		// if(record.json.pb_begin && record.json.pb_out)
		// outday = new Date((new
		// Date(Date.parse(record.json.pb_begin.replace(/-/g,
		// "/")))).getTime()+parseInt(record.json.pb_out)*24*3600*1000);

		var deds = new Ext.data.SimpleStore({
					fields : ['text', 'value'],
					data : [["学号", record.json.sid],
							["中文名", record.json.cname],
							["韩文名", record.json.kname],
							["学科", record.json.study],
							["护照名", record.json.ename],
							["生日", record.json.birthday]]
				});

	for(var i=0; i< yeararr.length; i++){
		var s = yeararr[i].name.substring(1,yeararr[i].name.length);
		var r = new Ext.data.Record({text:s, value:record.get("t"+s)});
		if(r.get("value") && "-"!=r.get("value"))
			deds.add(r)
		//cols = cols.concat([{header : yeararr[i].name.substring(1,yeararr[i].name.length),dataIndex : yeararr[i].name}]);
	}
		dgrid.setTitle(record.json.sid + '-' + record.json.cname + '-'
				+ record.json.kname);
		var imgel = Ext.getDom('stuphoto');
		if (imgel.src)
			imgel.src = photopath + '/photo/' + record.json.sid
					+ '.jpg'
		dgrid.reconfigure(deds, cmde);
	}

	this.add(grid);
	// 第三、调整，tbar分页,工具栏

}

Ext.extend(zz.Office.Crs_status_mngPanel, Ext.Panel, {

});
