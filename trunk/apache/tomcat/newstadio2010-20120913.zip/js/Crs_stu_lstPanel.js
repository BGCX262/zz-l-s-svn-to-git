// 显示历史学生名单
/**
 * 先获取学期和年份，得到orcale方案集合
 * 再返回当前学期的名单
 */

zz.Office.Crs_stu_lstPanel = function(config) {
	zz.Office.Crs_stu_lstPanel.superclass.constructor.call(this, config);

	// 加上服务器上的jsp数据生成

	var proxy = new Ext.data.HttpProxy({
				url : 'getstudentlist.do?tab=crs_stu_lst'
			});
	var recordType = new Ext.data.Record.create([{
				name : "id",
				type : "string"
			}, {
				name : "birthday",
				dateFormat : 'Y-m-d',
				type : "date"
			}, {
				name : "sex",
				type : "string"
			}, {
				name : "ename",
				type : "string"
			}, {
				name : "pass_id",
				type : "string"
			}, {
				name : "memo",
				type : "string"
			}, {
				name : "hasphoto",
				type : "string"
			}, {
				name : "sid",
				type : "string"
			}, {
				name : "iclass",
				type : "string"
			}, {
				name : "study",
				type : "string"
			}, {
				name : "cname",
				type : "string"
			}, {
				name : "kname",
				type : "string"
			}, {
				name : "subname",
				type : "string"
			}, {
				name : "result",
				type : "string"
			}, {
				name : "course",
				type : "string"
			}, {
				name : "pb_id",
				type : "string"
			}]);

	// 定义分析器
	var reader = new Ext.data.JsonReader({
				totalProperty : "results",
				root : "rows",
				id : "id"
			}, recordType);

	// 定义store
	var ds = new Ext.data.Store({
				id : 'dss_pi',
				proxy : proxy,
				reader : reader
			});

	ds.on('load', function() {
				var d = Ext.getCmp('cosmenu_csl');
				if (d.getText() != '全部') {
					ds.filter('course', d.getText());
				}
				putClassEl();
			});
			
	var dssub = new Ext.data.JsonStore({
				fields : ['text', 'view'],
				url : 'getlist.do?par=term_cmbo&datecode=' + (new Date().getTime()),
				root : 'root',
				sortInfo : {
					field : "text",
					direction : "DESC"
				}
			});
	dssub.on('load', function(elstore) {
		elstore.each(function(r) {
			r.set('view', '20'+r.get('text')+'学期'); 
			// r.set('view',
				// r.get('text') + '-' +
				// r.get('cos'));
			});
			var el = Ext.getCmp('termcombo_csl');
			//el.expand( ) ;
			//el.select(elstore.getCount()-1);
			var r = elstore.getAt(0);
			if(r && r.get('text')){
			var t = r.get('text');
			el.setValue(r.get('view'));
			ds.load({params :{term:r.get('text')} });
			} else 
				ds.load();
	});
	this.ds = dssub;
	var cm = new Ext.grid.ColumnModel({
				defaultSortable : true,
				defaultWidth : 40,
				columns : [new Ext.grid.RowNumberer(), {
							header : '学号',
							dataIndex : 'sid'
						}, {
							header : '课程',
							dataIndex : 'course'
						}, {
							header : '班级',
							width : 15,
							dataIndex : 'iclass'
						}, {
							header : '中文名',
							dataIndex : 'cname'
						}, {
							header : '韩文名',
							dataIndex : 'kname'
						}, {
							header : '护照名',
							dataIndex : 'ename'
						}, {
							header : '护照号',
							dataIndex : 'pb_id'
						}, {
							header : '性别',
							width : 15,
							dataIndex : 'sex'
						}, {
							header : '生日',
							renderer : Ext.util.Format.dateRenderer('Y-m-d'),
							dataIndex : 'birthday'
						}, {
							header : '学科',
							dataIndex : 'study'
						}, {
							header : '图书证',
							dataIndex : 'memo'
						}, {
							header : '结业证',
							hidden : true,
							dataIndex : 'pass_id'
						}, {
							header : '照片',
							hidden : true,
							dataIndex : 'hasphoto'
						}]
			});
	var exportbtn = new Ext.Button({
	    text: '&nbsp;导出Excel',
	    iconCls : 'excel',
	    handler: function() {
	        var vExportContent = grid.getExcelXml();
	        if (Ext.isIE || Ext.isSafari || Ext.isSafari2 || Ext.isSafari3) {
	            var fd=Ext.get('frmDummy');
	            if (!fd) {
	                fd=Ext.DomHelper.append(Ext.getBody(),{tag:'form',method:'post',id:'frmDummy',action:'exportexcel.jsp', target:'_blank',name:'frmDummy',cls:'x-hidden',cn:[
	                    {tag:'input',name:'exportContent',id:'exportContent',type:'hidden'}
	                ]},true);
	            }
	            fd.child('#exportContent').set({value:vExportContent});
	            fd.dom.submit();
	        } else {
	            document.location = 'data:application/vnd.ms-excel;base64,'+Base64.encode(vExportContent);
	        }}
	});
			
	var mytoolbar = new Ext.Toolbar([
			'','学期: ',{
				name : 'termcheck_csl',
				id : 'termcombo_csl',
				store : dssub,
				xtype : 'combo',
				mode : 'local',
				width : 100,
				triggerAction : 'all',
				// pageSize : 5, // 未实现分页，希望能按课程分页，第一页是当前cosname
				resizable : true,
				valueField : 'text',
				displayField : 'view',
				editable : false,
				listeners : {
					'select' : function(combo, record) {
						ds.load({params :{term:record.get('text')} });
						var el = Ext.getCmp('cosmenu_csl_all');
						el.handler();
						// Ext.getCmp('classel').text, record.get('text') );
					}
				}
				
				},'','-','',
			{
				id : 'cosmenu_csl',
				text : '全部',
				iconCls : 'im16x16',
				handler : function() {
					// putClassEl();
					if (!(this.text == '全部'))
						putClassEl();
					ds.clearFilter();
					fliterOptation(this.text, '全部班级');
				},
				xtype : 'splitbutton',
				menu : new Ext.menu.Menu({
							items : [{
								id : 'cosmenu_csl_all',
								text : '全部',
								iconCls : 'im16x16',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_csl').text);
									Ext.getCmp('cosmenu_csl').setText(this.text);
								}
							}, {
								text : '基本课程',
								iconCls : 'user-kid',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_csl').text);
									Ext.getCmp('cosmenu_csl').setText(this.text);
								}
							}, {
								text : '深化课程',
								iconCls : 'user-suit',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_csl').text);
									Ext.getCmp('cosmenu_csl').setText(this.text);

								}
							}, {
								text : '双学位课程',
								iconCls : 'user-girl',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_csl').text);
									Ext.getCmp('cosmenu_csl').setText(this.text);

								}
							}]
						})

			},
			'',
			'-',
			'',
			{
				id : 'classel_csl',
				text : '全部班级',
				iconCls : 'im16x16',
				handler : function() {
					var fls = this.text;
					fliterOptation(Ext.getCmp('cosmenu_csl').text, this.text);
				},
				xtype : 'splitbutton',
				menu : new Ext.menu.Menu({
							items : null
						}),
				listeners : {}
			},
			'',
			'-',
			'',
			'<img src=pic/s.gif style="background:url(images/find_user_icon.gif); width:16px" />',
			{
				width : 80,
				id : 'sidquery_csl',
				xtype : 'numberfield',
				emptyText : '输入学号...',
				// enableKeyEvents : true,
				listeners : {
					'blur' : function(el) {
						el.setValue('');
					},
					'render' : function(el1) {
						// el1.setValue('');
						Ext.get('sidquery_csl').on('keypress', function(e, el) {
							var querystr = 'sid';
							var k = e.getKey();
							if (k == 13) {
								ds.clearFilter()
								ds.filterBy(function(record) {
									var b = Ext.getCmp('cosmenu_csl').text
											.indexOf('全部') >= 0
											? true
											: Ext.getCmp('cosmenu_csl').text == record
													.get('course');
									b &= Ext.getCmp('classel_csl').text
											.indexOf('全部') >= 0
											? true
											: Ext.getCmp('classel_csl').text == record
													.get('iclass');
									return b
											&& record.get(querystr)
													.indexOf(el.value) > -1
								});
							}
						});

					}
				}
			}, '->',exportbtn,'', '']);
	// mytoolbar end

	var pagingBar = new Ext.PagingToolbar({
				disabled : true,
				pageSize : 10000,
				store : ds,
				displayInfo : true,
				displayMsg : '共有 {2}条记录',
				// hidden : true,
				emptyMsg : "没有数据"
			});

	var grid = new Ext.grid.EditorGridPanel({
				id : 'datagrid_csl',
				cm : cm,
				store : ds,
				// width : 660,
				// height : 600,
				region : "center",
				margins : '2 2 2 2',
				selModel : new Ext.grid.RowSelectionModel({
					singleSelect:true,
					listeners : {
						'rowselect' : function(sm, row, rec) {
							setDetailsPanel(rec);
						}
					}
				}),
				bbar : pagingBar,
				stripeRows : true ,				
				viewConfig : {
				               forceFit : true,
				               getRowClass : function(record,rowIndex,rowParams,store){
				                   //签证快到期的红色显示
				               		/*var s = record.json.pb_begin!=null && record.json.pb_out!=null && record.json.pbtimeout!=null 
				               		? record.json.pbtimeout.replace(/-/g,"/") : null;
				               		var d = s != null ?Date.parse(s) : null;
				               		var to = 20*24*3600*1000;	//20天
				                   if(d!=null && (d-new Date().getTime())<to){
				                       return 'x-grid-record-red';
				                   }else{
				                       return '';
				                   } */    
				               }
				},
				loadMask : {
					msg : '正在载入数据,请稍等...'
				},
				// title : '公司列表',
				tbar : mytoolbar,
				listeners : {
					'render' : function(el) {
						// grid.on("afteredit", function(e) {
						// saveBtnHandler(null, e);
						// }, grid);
					},
					'beforerender' : function(gd) {
						// debugger;
					}
				}
			});

	function fliterOptation(cosname, classname, subjectstr) {
		// 使用fliteby的处理函数，处理班级课程间过滤联动关系,
		// 因为是单科成绩表，所以联动需加入subcombo的值
		ds.clearFilter();
		ds.filterBy(function(re) {
					var b = true;
					// 不能显示没有选课的人，考虑吧课程查询作为触发远程查询
					if (cosname.indexOf('全部') >= 0) { // 
						return b;
					} else if (classname.indexOf('全部') >= 0) { // 筛选class时，要考虑course的筛选继续有效
						b &= re.get('course') == cosname;
					} else {
						b &= re.get('course') == cosname;
						b &= re.get('iclass') == classname;
					}
					if (!(Ext.isEmpty(subjectstr)))
						b &= re.get('subname') == subjectstr
								|| Ext.isEmpty(re.get('subname'));
					return b;
				});
	}

	function putClassEl() {
		// 从grid store中提取班级
		Ext.getCmp('classel_csl').menu.removeAll();
		Ext.getCmp('classel_csl').menu.add({
					text : '全部班级',
					iconCls : 'im16x16',
					handler : function() {
						var s = this.text;
						fliterOptation(Ext.getCmp('cosmenu_csl').text, this.text);
						Ext.getCmp('classel_csl').setText(this.text);
					}
				});
		Ext.getCmp('classel_csl').setText('全部班级');
		var sz = '|';
		ds.data.each(function(re) {
					if (re.get('course') != Ext.getCmp('cosmenu_csl').getText())
						return;
					var c = re.get('iclass');
					if (c && c != '' && c != '-') {
						if (sz.indexOf('|' + c + '|') < 0) { // sz like
							// '|1-2|2-1|3-5|'
							sz += c + '|';
							var newclass = new Ext.menu.Item({
										text : c,
										iconCls : 'user-girl',
										handler : function() {
											fliterOptation(
													Ext.getCmp('cosmenu_csl').text,
													this.text);
											Ext.getCmp('classel_csl').setText(c);
										}
									});
							var m = Ext.getCmp('classel_csl').menu;
							// debugger
							m.add(newclass);
						}

					}
				});
		// 班级结束
	}

	function setDetailsPanel(record) {
		var dgrid = Ext.getCmp('detailsgrid');
		var cmde = new Ext.grid.ColumnModel({
					defaultWidth : 50,
					columns : [{
								header : '类    别',
								align : 'center',
								dataIndex : 'text'
							}, {
								header : '内    容',
								align : 'center',
								dataIndex : 'value'
							}]
				});
		// var outday = "";
		// if(record.json.pb_begin && record.json.pb_out)
		// outday = new Date((new
		// Date(Date.parse(record.json.pb_begin.replace(/-/g,
		// "/")))).getTime()+parseInt(record.json.pb_out)*24*3600*1000);

		var deds = new Ext.data.SimpleStore({
					fields : ['text', 'value'],
					data : [["学号", record.json.sid],
							["中文名", record.json.cname],
							["韩文名", record.json.kname],
							["英文名", record.json.ename],
							["学科", record.json.study],
							["课程", record.json.course],
							["班级", record.json.iclass],
							["护照名", record.json.ename],
							["护照号", record.json.pb_id],
							["签证号", record.json.pb_type],
							["签证起始", record.json.pb_begin],
							["签证终止", record.json.pbtimeout],
							["生日", record.json.birthday],
							["图书证", record.json.memo]]
				});

		dgrid.setTitle(record.json.sid + '-' + record.json.cname + '-'
				+ record.json.kname);
		var imgel = Ext.getDom('stuphoto');
		if (imgel.src)
			imgel.src =  photopath + '/photo/' + record.json.sid
					+ '.jpg'
		dgrid.reconfigure(deds, cmde);
	}

	this.add(grid);
	// 第三、调整，tbar分页,工具栏

}

Ext.extend(zz.Office.Crs_stu_lstPanel, Ext.Panel, {

});
