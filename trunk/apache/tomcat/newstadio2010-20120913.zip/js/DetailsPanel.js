Ext.ns("zz", "zz.Office", "zz.Util");
zz.Office.DetailsPanel = Ext.extend(Ext.Panel, {
	initComponent : function() {
		// 一些初始化工作
		zz.Office.DetailsPanel.superclass.initComponent.call(this);
		this._cache = {};

		var proxy = new Ext.data.HttpProxy({
					url : 'getlist.do?par=cos_count&cos=all'
				});

		var recordType = new Ext.data.Record.create([{
					name : "cos_name",
					type : "string"
				}, {
					name : "sex",
					type : "string"
				}, {
					name : "count",
					type : "string"
				}]);

		// 定义分析器
		var reader = new Ext.data.JsonReader({
			totalProperty : "course",
			root : "root"
				// id : "cos_name"
			}, recordType);

		// 定义store
		var dssub = new Ext.data.GroupingStore({
					id : 'dssubid',
					proxy : proxy,
					// groupField : 'cos_name',
					sortInfo : {
						field : 'cos_name',
						direction : 'DESC'
					},
					reader : reader
				});
		// this.ds = dssub;
		this.on('render', function() {
					dssub.load();
				});
		dssub.on('load', function(elstore) {

				});
		// var sm = new Ext.grid.CheckboxSelectionModel();
		var cm = new Ext.grid.ColumnModel({
					defaultSortable : true,
					defaultWidth : 50,
					columns : [{
								header : '课程',
								align : 'center',
								dataIndex : 'cos_name'
							}, {
								header : '性别',
								editor : new Ext.form.TextField({
											allowBlank : true
										}),
								align : 'center',
								dataIndex : 'sex'
							}, {
								header : '合计',
								editor : new Ext.form.TextField({
											allowBlank : true
										}),
								align : 'center',
								dataIndex : 'count'
							}]
				});

		var grid = new Ext.grid.EditorGridPanel({
					id : 'detailsgrid',
					bodyStyle : 'text-align:left',
					cm : cm,
					store : dssub,
					region : "center",

					viewConfig : {
								enableGrouping : false,
								startCollapsed : false,
								getRowClass : function(record, rowIndex,
										rowParams, store) {
									if(record.data.cos_name==null)	//可能是其他定制grid，退出
										return '';
									if (record.data.sex == '合计') 
											return 'zz-grid-record-red';
									else if (record.data.cos_name.indexOf('总计')>=0){										
											return 'zz-grid-record-summry';

									} else {
										return '';
									}
								},
								forceFit : true
							},
					loadMask : {
						msg : '正在载入数据,请稍等...'
					},
					title : '学生信息概览',
					selModel : new Ext.grid.RowSelectionModel({
								singleSelect : true
							})
				});
		var photopan = new Ext.Panel({
			region : 'north',
			autoHeight : true,
			// bodyStyle:' margin: 0 150px 0 150px;',

			// height : 300,
			html : '<div style="background-color:#fff;width:150px;margin:0 auto;text-align:left;padding:20px;">'
					+ '<div class="img-wrapper">'
					+ '<div ><div ><img id="stuphoto" src="'
					+ Ext.BLANK_IMAGE_URL
					+ '" width="150px" height="190px"  alt="学生照片" /></div>'
					+ '</div></div></div>'

		});

		/*
		 * var degrid = new Ext.grid.PropertyGrid({ id:'detailgrid', title :
		 * 'Properties Grid', region : 'center', autoHeight : true, width : 300,
		 * //renderTo : 'grid-ct',, source : {}, viewConfig : { forceFit : true,
		 * scrollOffset : 2 // the grid will never have scrollbars } listeners:{
		 * 'render':function(e){ //欢迎页面显示内容 Ext.Ajax.request({ url :
		 * 'getlist.do?par=cos_count&cos=all', params : {},
		 * //参数是成绩记录id和subname、result success : function() { el.setSource({
		 * "基本课程" : record.json.sid, "深化课程" : record.json.cname, "双学位课程" :
		 * record.json.kname, "合计" : record.json.ename }); }, failure :
		 * function() { el.setSource({ "数据加载失败" : null }); } });
		 *  }, 'beforeedit': function(e){ //禁止编辑 e.cancel=true; return false; }
		 * });
		 */

		this.add(photopan, grid);
	},
	addPanel : function(name, panel) {
		if (!this._cache)
			this._cache = {};
		this._cache[name] = panel;
	}
});
