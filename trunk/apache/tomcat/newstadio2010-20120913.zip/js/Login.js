Ext.BLANK_IMAGE_URL = 'pic/blank.gif';
var login = function() {
	Ext.QuickTips.init();
	Ext.lib.Ajax.defaultPostHeader += ";charset=utf-8";

	// 设置保存用户名
	var cp = new Ext.state.CookieProvider({expires: new Date(new Date().getTime()+(1000*60*60*24*45))});
	Ext.state.Manager.setProvider(cp);
	var un = cp.get('login');

	var form = new Ext.FormPanel({
		frame : false,
		labelWidth : 60,
		labelAlign : 'right',
		border : true,
		region : "center",
		defaultType : 'textfield',
		bodyStyle : 'padding-left:10px; padding-top:16px;',
		defaults : {
			border : false,
			y : 20,
			allowBlank : false,
			msgTarget : 'side',
			anchor : '90%',
			blankText : '该字段不允许为空'
		},
		waitMsgTarget : true,
		items : [{
					fieldLabel : '登录帐号',
					name : 'user',
					id: 'userid',
					regex : /^[0-9a-zA-Z]{2,6}$/,
					regexText : '只能为两到六位的大小写字母。',
					value: un
				}, {
					fieldLabel : '登录密码',
					name : 'pass',
					inputType : 'password',
					regex : /^.{4,}$/,
					regexText : '长度不能少于4位'
				}, {
					xtype : 'panel',
					layout : 'column',
					items : [{
								width : 130,
								layout : 'form',
								border : false,
								items : [{
											fieldLabel : '效 验 码',
											anchor : '98%',
											name : 'checkcode',
											xtype : 'textfield',
											allowBlank : false,
											msgTarget : 'side',
											blankText : '该字段不允许为空'
										}]
							}, {
								xtype : 'checkCode',
								id : 'codeimg',
								src : 'img.do',
								width : 60,
								height : 20,
								handler : true
							}]
				}, {
					boxLabel : '两周内自动登录',
					name : 'saved',
					xtype : 'checkbox'
				}],

		buttons : [{
			text : '登陆',
			id : 'submitbtn',
			handler : function() {
				if (!form.getForm().isValid()) {
					return;
				}
				var ps = form.getForm().findField('pass').getValue();
				if (ps)
					form.getForm().findField('pass').setValue(hex_md5(ps));
				// 使用MD5加密
				// 服务器端发送随机字符串，与密码经过md5后的字符串合并，再经过md5再传送
				// 服务器端把库里的密码（已经md5加密）与发送的字符串合并后再与请求中字符串比较，这样传送的密码串每次不同
				Ext.Ajax.request({
					url : 'img.do?datecode=' + (new Date().getTime()),
					params : {
						param : 'md5'
					},
					success : function(e) { // 取得md5随机字符串
						var responseObj = Ext.util.JSON.decode(e.responseText);

						if (!responseObj.success || responseObj.md5oper == null) {
							alert(responseObj.errorMessage == null
									? '未知错误'
									: responseObj.errorMessage);
							Ext.getCmp('codeimg').fireEvent('click'); // 刷新校验码
							return;
						}
						form.getForm().findField('pass').setValue(hex_md5(form
								.getForm().findField('pass').getValue()
								+ responseObj.md5oper))
						form.getForm().submit({
									waitMsg : '正在提交，请稍等...',
									success : function(f, a) {
										cp.set('login',f.findField('user').getValue());  //保存登录名
										window.location.href = a.result.url;
										// window.open('main.html','','fullscreen=1');
									},
									failure : function() {
										Ext.getCmp('codeimg').onClick(); // 刷新校验码
										form.getForm().findField('pass').setValue('');
										form.getForm().findField('checkcode').setValue('');
									},
									url : 'check.do?datecode=' + (new Date().getTime())
								});
					},
					failure : function() {
						alert('未能成功!');
						Ext.getCmp('codeimg').onClick(); // 刷新校验码

					}
						// scope : storeObj
				});
			}
		}, {
			text : '取消',
			handler : function() {
				form.getForm().reset();
			}
		}]

	});

	var panel = new Ext.Panel({
				renderTo : 'loginpanel',
				layout : "border",
				width : 525,
				height : 290,
				defaults : {
					border : false
				},
				items : [{
							region : "north",
							height : 56,
							html : '<img src="pic/head.gif"/>'
						}, {
							region : "south",
							height : 56,
							html : '<img src="pic/foot.gif"/>'
						}, {
							region : "west",
							width : 255,
							html : '<img src="pic/left.gif"/>'
						}, {
							region : "center",
							bodyStyle : 'padding:15px 5px 0 25px;',
							layout : 'fit',
							items : [form]
						}]
			});

	Ext.get('loginpanel').setStyle('position', 'absolute')
			.center(Ext.getBody());
	form.getForm().on('beforeaction', function() {
				// alert(form.getForm().findField('pass').value)
				// alert(form.getForm().findField('pass').getValue())
				// console.dir(form.getForm());

			});

	// 设置快捷键
	var keydown = new Ext.KeyMap(Ext.getBody(), [{
						key : [10, 13],
						fn : function() {
							var btn = Ext.getCmp('submitbtn')
							btn.handler();
						}
					}])
};

//先检查是否在保质期内
var checkme = function(){
				Ext.Ajax.request({
					url : 'index.do?datecode=' + (new Date().getTime()),
					params : {},
					success : function(e) { // 取得md5随机字符串
						var responseObj = Ext.util.JSON.decode(e.responseText);
						if (responseObj.success && responseObj.url != null) 
										window.location.href = responseObj.url;
					}
				});
};

Ext.onReady(function() {

	checkme();
	login();
		// keydown();
	});
