
var photopath = "";

Ext.onReady(function() {

	Ext.BLANK_IMAGE_URL = 'pic/s.gif';
	Ext.QuickTips.init();
	Ext.lib.Ajax.defaultPostHeader += ";charset=utf-8";

	// 1、创建head部分
		var head = new Ext.Panel( {
			region : 'north',
			border : false,
			html : '<div style="background:url(./extjs/resources/images/default/toolbar/bg.gif) repeat;height:78px;">'
			+ '<div style="float:left;font:normal 12px tahoma, arial, sans-serif, 宋体;margin:10px 0 0 10px;">'
			+ '<h3><font size="5" color=#005588>&nbsp;DUSC&nbsp;学生数据管理系统</font></h3></div>'
					+ '<div	style="float:right;margin:10px;font:normal 12px tahoma, arial, sans-serif, 宋体;" >'
					+ '当前用户：&nbsp;<span id="un" style="padding: 0pt 10px; font-size: 14px; background-color: rgb(21, 66, 139); color: rgb(255, 255, 255);">&nbsp;'+ user1 + '&nbsp;</span>'
					+ '&nbsp;&nbsp;<a href="./logout.jsp">注销</a>&nbsp;&nbsp;&nbsp;&nbsp;'
			+'</div></div>',
			height : 55
		});

		// 2、创建foot部分
		var foot = new Ext.Panel( {
			region : 'south',
			html : '<div style="background:url(./extjs/resources/images/default/toolbar/bg.gif) repeat-x; height:120px; background-color:#D0DEF0;">'
				+ '<div style="float:left;font:normal 12px tahoma, arial, sans-serif, 宋体;margin:10px 0 0 10px;">'
				+ '&nbsp; &nbsp;'
				+ '</div><div	style="float:right;margin:10px;font:normal 12px tahoma, arial, sans-serif, 宋体;" >'
				+ '版权所有：<a href="mailto:zezhang1015@21cn.com">zezhang1015@21cn.com</a></div>'
				+ '</div>'
,
			height : 35
		});
		
		// 3、创建east部分
		var details = new zz.Office.DetailsPanel( {
			id: 'detailp',
			region : 'east',
			layout : 'border',
			width: 250,
			bodyStyle :'text-align:center;',
			/*html : '<div style="background:url(./extjs/resources/images/default/toolbar/bg.gif) repeat-x; height:120px; background-color:#D0DEF0;">'
				+ '<div style="float:left;font:normal 12px tahoma, arial, sans-serif, 宋体;margin:10px 0 0 10px;">'
				+ '&nbsp; &nbsp;'
				+ '</div><div	style="float:right;margin:10px;font:normal 12px tahoma, arial, sans-serif, 宋体;" >'
				+ '版权所有：<a href="mailto:zezhang1015@21cn.com">zezhang1015@21cn.com</a></div>'
				+ '</div>',*/

			collapsible : true
		});

		var t1 = new Ext.tree.TreePanel( {
			border : false,
			rootVisible : false,
			root : new Ext.tree.AsyncTreeNode( {
				text : "信息管理",
				expanded : true,
				children : [  {	
					id : "personinfo",
					text : "基本信息",
					qtip : "学生身份、学习信息查询与管理",
					leaf : true
				},  {	
					id : "passmng",
					text : "护照签证管理",
					qtip : "学生护照、签证有效期等查询与管理",
					leaf : true
				},  {	
					id : "photoview",
					text : "照片列表",
					leaf : true
				},  {	
					id : "electmng",
					text : "选课管理",
					leaf : true
				}]
			})
		});

		var t2 = new Ext.tree.TreePanel( {
			border : false,
			rootVisible : false,
			root : new Ext.tree.AsyncTreeNode( {
				text : "成绩管理",
				expanded : true,
				children : [  {	//用于触发成绩grid
					id : "totalResult",
					text : "成绩汇总",
					leaf : true
				},  {	//用于触发单科成绩grid
					id : "singleResult",
					text : "单科成绩",
					leaf : true
				}, {
					id : "subjectmng",
					text : "课目管理",
					leaf : true
				}]
			})
		});

		var t3 = new Ext.tree.TreePanel( {
			border : false,
			rootVisible : false,
			root : new Ext.tree.AsyncTreeNode( {
				text : "历史数据管理",
				expanded : true,
				children : [  {	
					id : "crs_status_mng",
					text : "学籍记录",
					leaf : true
				},  {	
					id : "crs_stu_lst",
					text : "历届学生名单",
					leaf : true
				},  {	
					id : "crs_changeDB",
					text : "更改当前数据库",
					leaf : true
				}]
			})
		});
		
		var t4 = new Ext.tree.TreePanel( {
			border : false,
			rootVisible : false,
			root : new Ext.tree.AsyncTreeNode( {
				text : "系统管理",
				expanded : true,
				children : [{
					id : "membersmng",
					text : "用户管理",
					children : [ {
						id : "permission",
						text : "权限管理",
						leaf : true
					}, {
						id : "permissionType",
						text : "权限类别",
						leaf : true
					}]
				}, {
					id : "pwmng",
					text : "密码重置",
					leaf : true
				}]
			})

		});

		var leftmenu = new zz.Office.LeftMenu( {
			title : '我的办公桌',
		//	items : [ {
			//	title : '我的办公桌',
		//		items : [t1]
		//	}, {
		//		title : '主数据管理',
		//		items : [t2]
		//	}]
		 trees : [t1, t2, t3, t4]
		});

		var mainTab = new zz.Office.MainingPanel( {
			style : 'padding:0 6px 0 0',
			autoScroll : true,

			region : 'center',
			deferredRender : false,
			activeTab : 0,
			resizeTabs : true,
			inTabWidth : 100,
			tabWidth : 90,
			enableTabScroll : true,
			items : [{
				title : '首页',
				html : '<div id="mainpage" style="background: transparent url(pic/main.jpg) no-repeat scroll center center;; height:508px;"></div>'
			}]
		});

		// 5、建立leftmenu和mainTab两者之间的关系
		leftmenu.on("nodeClick", function(nodeAttr) {
			mainTab.loadTab(nodeAttr);
		});
		// 6、创建布局
		var viewport = new Ext.Viewport( {
			layout : 'border',
			style : 'border:#024459 2px solid;',
			items : [head, foot, leftmenu, mainTab ,details]
		});

	});