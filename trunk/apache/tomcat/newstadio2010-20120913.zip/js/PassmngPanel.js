// 管理护照签证

zz.Office.PassmngPanel = function(config) {
	zz.Office.PassmngPanel.superclass.constructor.call(this, config);

	// 加上服务器上的jsp数据生成

	var proxy = new Ext.data.HttpProxy({
				url : 'getstudentlist.do?tab=passmng'
			});
	var recordType = new Ext.data.Record.create([{
				name : "id",
				type : "string"
			}, {
				name : "birthday",
				type : "date",
				dateFormat : 'Y-m-d'
			}, {
				name : "sex",
				type : "string"
			}, {
				name : "ename",
				type : "string"
			}, {
				name : "sid",
				type : "string"
			}, {
				name : "iclass",
				type : "string"
			}, {
				name : "cname",
				type : "string"
			}, {
				name : "kname",
				type : "string"
			}, {
				name : "course",
				type : "string"
			}, {
				name : "pb_id",
				type : "string"
			}, {
				name : "pb_type",
				type : "string"
			}, {
				name : "pbtimeout",
				type : "date",
				dateFormat : 'Y-m-d'
			}, {
				name : "pb_out",
				type : "string"
			}, {
				name : "pb_begin",
				type : "date",
				dateFormat : 'Y-m-d'
			}]);

	// 定义分析器
	var reader = new Ext.data.JsonReader({
				totalProperty : "results",
				root : "rows",
				id : "id"
			}, recordType);

	// 定义store
	var ds = new Ext.data.Store({
				id : 'dss_psm',
				proxy : proxy,
				reader : reader
			});
	this.ds = ds;
	ds.on('load', function() {
				var d = Ext.getCmp('cosmenu_psm');
				if (d.getText() != '全部') {
					ds.filter('course', d.getText());
				}
				putClassEl();
			});
	var delbtn = new zz.Util.ButtonSelectionModel({
				dataIndex : 'id',
				url : 'ModifyResult.do?edit=delstu&datecode='
						+ (new Date().getTime()),
				saveconfirm : 'saveconfirm_pi', // 增加属性saveconfirm，用于记录saveconfirm的id，作为是否允许删除标志
				align : 'left',
				// hidden : true,
				listeners : {
					'rowselect' : function(sm, row, rec) {
						setDetailsPanel(rec);
					}
				}
			});
	var cm = new Ext.grid.ColumnModel({
				defaultSortable : true,
				defaultWidth : 40,
				columns : [new Ext.grid.RowNumberer(), {
							header : '学号',
							dataIndex : 'sid'
						}, {
							header : '课程',
							dataIndex : 'course'
						}, {
							header : '班级',
							hidden : true,
							width : 15,
							dataIndex : 'iclass'
						}, {
							header : '中文名',
							dataIndex : 'cname'
						}, {
							header : '韩文名',
							dataIndex : 'kname'
						}, {
							header : '护照名',
							editor : new Ext.form.TextField({
									// allowBlank : true
									}),
							dataIndex : 'ename'
						}, {
							header : '护照号',
							editor : new Ext.form.TextField({
									// allowBlank : true
									}),
							dataIndex : 'pb_id'
						}, {
							header : '签证号',
							editor : new Ext.form.TextField({
									// allowBlank : true
									}),
							dataIndex : 'pb_type'
						}, {
							header : '性别',
							width : 15,
							dataIndex : 'sex'
						}, {
							header : '生日',
							renderer : Ext.util.Format.dateRenderer('Y-m-d'),
							dataIndex : 'birthday'
						}, {
							header : '签证起始日',
							editor : new Ext.form.DateField({
										format : 'Y-m-d'
									}),
							renderer : Ext.util.Format.dateRenderer('Y-m-d'),
							dataIndex : 'pb_begin'
						}, {
							header : '有效期',
							width : 15,
							editor : new Ext.form.NumberField({
									// allowBlank : true
									}),
							dataIndex : 'pb_out'
						}, {
							header : '签证到期日',
							// editor : new
							// Ext.form.DateField({format:'Y-m-d'}),
							renderer : Ext.util.Format.dateRenderer('Y-m-d'),
							dataIndex : 'pbtimeout'
						}]
			});
	var exportbtn = new Ext.Button({
				text : '&nbsp;导出Excel',
				iconCls : 'option',
				handler : function() {
					var vExportContent = grid.getExcelXml();
					if (Ext.isIE || Ext.isSafari || Ext.isSafari2
							|| Ext.isSafari3) {
						var fd = Ext.get('frmDummy');
						if (!fd) {
							fd = Ext.DomHelper.append(Ext.getBody(), {
										tag : 'form',
										method : 'post',
										id : 'frmDummy',
										action : 'exportexcel.jsp',
										target : '_blank',
										name : 'frmDummy',
										cls : 'x-hidden',
										cn : [{
													tag : 'input',
													name : 'exportContent',
													id : 'exportContent',
													type : 'hidden'
												}]
									}, true);
						}
						fd.child('#exportContent').set({
									value : vExportContent
								});
						fd.dom.submit();
					} else {
						document.location = 'data:application/vnd.ms-excel;base64,'
								+ Base64.encode(vExportContent);
					}
				}
			});

	var mytoolbar = new Ext.Toolbar([
			'',
			{
				id : 'cosmenu_psm',
				text : '全部',
				iconCls : 'im16x16',
				handler : function() {
					// putClassEl();
					if (!(this.text == '全部'))
						putClassEl();
					ds.clearFilter();
					fliterOptation(this.text, '全部班级');
				},
				xtype : 'splitbutton',
				menu : new Ext.menu.Menu({
							items : [{
								text : '全部',
								iconCls : 'im16x16',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_psm').text);
									Ext.getCmp('cosmenu_psm')
											.setText(this.text);
								}
							}, {
								text : '基本课程',
								iconCls : 'user-kid',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_psm').text);
									Ext.getCmp('cosmenu_psm')
											.setText(this.text);
								}
							}, {
								text : '深化课程',
								iconCls : 'user-suit',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_psm').text);
									Ext.getCmp('cosmenu_psm')
											.setText(this.text);

								}
							}, {
								text : '双学位课程',
								iconCls : 'user-girl',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_psm').text);
									Ext.getCmp('cosmenu_psm')
											.setText(this.text);

								}
							}]
						})

			},
			'',
			'-',
			'',
			{
				id : 'classel_psm',
				text : '全部班级',
				iconCls : 'im16x16',
				handler : function() {
					var fls = this.text;
					fliterOptation(Ext.getCmp('cosmenu_psm').text, this.text);
				},
				xtype : 'splitbutton',
				menu : new Ext.menu.Menu({
							items : null
						}),
				listeners : {}
			},
			'',
			'-',
			'',
			'<img src=pic/s.gif style="background:url(images/find_user_icon.gif); width:16px" />',
			{
				width : 80,
				id : 'sidquery_psm',
				xtype : 'numberfield',
				emptyText : '输入学号...',
				// enableKeyEvents : true,
				listeners : {
					'blur' : function(el) {
						el.setValue('');
					},
					'render' : function(el1) {
						// el1.setValue('');
						Ext.get('sidquery_psm').on('keypress', function(e, el) {
							var querystr = 'sid';
							var k = e.getKey();

							if (k == 13) {
								ds.clearFilter()
								ds.filterBy(function(record) {
									var b = Ext.getCmp('cosmenu_psm').text
											.indexOf('全部') >= 0
											? true
											: Ext.getCmp('cosmenu_psm').text == record
													.get('course');
									b &= Ext.getCmp('classel_psm').text
											.indexOf('全部') >= 0
											? true
											: Ext.getCmp('classel_psm').text == record
													.get('iclass');
									return b
											&& record.get(querystr)
													.indexOf(el.value) > -1
								});
							}
						});

					}
				}
			}, '->', exportbtn, '', '-', '', {
				id : 'saveconfirm_psm',
				text : '编辑选项',
				width : 80,
				handler : null,
				xtype : 'splitbutton',
				menu : new Ext.menu.Menu({
					items : [{
								text : '修改前需确认',
								handler : function() {
									grid.on("afteredit", function(e) {
												saveBtnHandler(null, e)
												return false; // 阻止事件继续传播
											}, grid);
									Ext.getCmp('saveconfirm_psm')
											.setText(this.text);
									Ext.getCmp('saveconfirm_psm').handler = null;
								}
							}, {
								text : '不提示直接修改',
								handler : function() {
									grid.on("afteredit", function(e) {
												saveBtnHandler(null, e)
												return false;
											}, grid);
									Ext.getCmp('saveconfirm_psm')
											.setText(this.text);
									Ext.getCmp('saveconfirm_psm').handler = null;
								}
							}, {
								text : '修改后统一提交',
								handler : function() {
									grid.un("afteredit", function(e) {
												saveBtnHandler(null, e)
												return false;
											}, grid); // 取消grid编辑后的提交动作
									Ext.getCmp('saveconfirm_psm')
											.setText(this.text);
									Ext.getCmp('saveconfirm_psm').handler = saveBtnHandler;
								}
							}]
				})
				// arrowHandler: function(){Ext.MessageBox.alert("","ooo")}
			}]);
	// mytoolbar end

	var pagingBar = new Ext.PagingToolbar({
				disabled : true,
				pageSize : 10000,
				store : ds,
				displayInfo : true,
				displayMsg : '共有 {2}条记录',
				// hidden : true,
				emptyMsg : "没有数据"
			});

	var grid = new Ext.grid.EditorGridPanel({
				id : 'datagrid_psm',
				cm : cm,
				store : ds,
				// width : 660,
				stripeRows : true,
				region : "center",
				margins : '2 2 2 2',
				bbar : pagingBar,
				loadMask : {
					msg : '正在载入数据,请稍等...'
				},
				stripeRows : true,
				selModel : delbtn,
				viewConfig : {
					forceFit : true,
					getRowClass : function(record, rowIndex, rowParams, store) {
						// 签证快到期的红色显示
						var s = record.data.pb_begin != null
								&& record.json.pb_out != null
								&& record.data.pbtimeout != null
								? record.data.pbtimeout
								: null;
						var d = s // != null ?Date.parse(s) : null;
						var to = 20 * 24 * 3600 * 1000; // 20天
						if (d != null && (d - new Date().getTime()) < to) {
							return 'x-grid-record-red';
						} else {
							return '';
						}
					}
				},
				tbar : mytoolbar,
				listeners : {
					'render' : function(el) {
						// grid.on("afteredit", function(e) {
						// saveBtnHandler(null, e);
						// }, grid);
					},
					'beforerender' : function(gd) {
						// debugger;
					}
				}
			});

	function fliterOptation(cosname, classname, subjectstr) {
		// 使用fliteby的处理函数，处理班级课程间过滤联动关系,
		ds.clearFilter();
		ds.filterBy(function(re) {
					var b = true;
					// 不能显示没有选课的人，考虑吧课程查询作为触发远程查询
					if (cosname.indexOf('全部') >= 0) { // 
						return b;
					} else if (classname.indexOf('全部') >= 0) { // 筛选class时，要考虑course的筛选继续有效
						b &= re.get('course') == cosname;
					} else {
						b &= re.get('course') == cosname;
						b &= re.get('iclass') == classname;
					}
					if (!(Ext.isEmpty(subjectstr)))
						b &= re.get('subname') == subjectstr
								|| Ext.isEmpty(re.get('subname'));
					return b;
				});
	}

	function putClassEl() {
		// 从grid store中提取班级
		Ext.getCmp('classel_psm').menu.removeAll();
		Ext.getCmp('classel_psm').menu.add({
					text : '全部班级',
					iconCls : 'im16x16',
					handler : function() {
						var s = this.text;
						fliterOptation(Ext.getCmp('cosmenu_psm').text,
								this.text);
						Ext.getCmp('classel_psm').setText(this.text);
					}
				});
		Ext.getCmp('classel_psm').setText('全部班级');
		var sz = '|';
		ds.data.each(function(re) {
					if (re.get('course') != Ext.getCmp('cosmenu_psm').getText())
						return;
					var c = re.get('iclass');
					if (c && c != '' && c != '-') {
						if (sz.indexOf('|' + c + '|') < 0) { // sz like
							// '|1-2|2-1|3-5|'
							sz += c + '|';
							var newclass = new Ext.menu.Item({
										text : c,
										iconCls : 'user-girl',
										handler : function() {
											fliterOptation(
													Ext.getCmp('cosmenu_psm').text,
													this.text);
											Ext.getCmp('classel_psm')
													.setText(c);
										}
									});
							var m = Ext.getCmp('classel_psm').menu;
							// debugger
							m.add(newclass);
						}

					}
				});
		// 班级结束
	}

	/**
	 * 全部修改操作 btn-提交按钮控件 e-当逐条提交修改时的编辑事件，含当前record等 ***********************
	 */
	function saveBtnHandler(btn, e) {
		var a = Ext.getCmp('saveconfirm_psm');
		if (a.text != '不提示直接修改' && a.text != '修改前需确认' && a.text != '修改后统一提交')
			return;
		else if (a.text == '修改后统一提交' && !btn) // 当为'修改后统一提交'时不响应afertrowedit事件
			return;

		var storeObj = ds;
		var modifiedRecords = storeObj.getModifiedRecords();
		var submitRecords = [];

		for (var i = 0, len = modifiedRecords.length; i < len; i++) {
			// 原型语句 submitRecords.push(storeObj.isWithAllFields === true ?
			// modifiedRecords[i].data : modifiedRecords[i].modified); //
			// 获取Record之中的实体数据
			submitRecords.push({
						id : modifiedRecords[i].json.id,
						sid : modifiedRecords[i].data.sid,

						pb_id : modifiedRecords[i].data.pb_id,
						pb_type : modifiedRecords[i].data.pb_type,
						pb_begin : modifiedRecords[i].data.pb_begin
								? modifiedRecords[i].data.pb_begin
										.format('Y-m-d')
								: 'null',
						// pbtimeout : modifiedRecords[i].data.pbtimeout,
						pb_out : modifiedRecords[i].data.pb_out
					});
		}
		if (submitRecords.length <= 0)
			return;
		if (a.text != '修改后统一提交') { // 只有当前记录被修改
			if (modifiedRecords.length > 1) {
				if (confirm('有陈旧修改数据，按“确定”清理数据重新输入，或“取消”后修改选项为“统一提交”！'))
					storeObj.commitChanges();
				storeObj.reload();
				return;
			} else {
				if (a.text == '不提示直接修改' || confirm('数据修改将被提交，是否继续？'))
					Ext.Ajax.request({
								url : 'ModifyResult.do?edit=perinfoedit&datecode='
										+ (new Date().getTime()),
								params : {
									submitData : Ext.util.JSON
											.encode(submitRecords)
								},
								success : function() {
									// alert("保存已成功。");
									storeObj.commitChanges();
								},
								failure : function() {
									alert('你的改变未能正常保存成功!');
								}
							});
			}

		} else { // 统一提交
			if (submitRecords.length == 0) {
				alert('没有发现修改过的记录，没有内容提交！');
				return;
			}

			// debugger
			btn.disable();
			if (confirm("您确定要进行该操作？") == true) {
				// 正在保存改变，请等待...
				Ext.Ajax.request({
					url : 'ModifyResult.do?edit=perinfoedit&datecode='
							+ (new Date().getTime()),
					params : {
						submitData : Ext.util.JSON.encode(submitRecords)
					},
					success : function() {
						alert("保存已成功。");
						storeObj.commitChanges();
						if (btn)
							btn.enable();
					},
					failure : function() {
						alert('你的改变未能正常保存成功!');
						if (btn)
							btn.enable();
					}
						// scope : storeObj
					});
			} else {
				btn.enable();
			}
		}
	}
	/** 修改结束 *********************** */

	/**
	 * 显示护照影印件
	 */
	function  showUrl(value){
		return "<a href='pbimg.jsp?pbid="+value+"' target='_blank'>"+value+"</a>";
	}
	
	function setDetailsPanel(record) {
		var dgrid = Ext.getCmp('detailsgrid');
		var cmde = new Ext.grid.ColumnModel({
					defaultWidth : 50,
					columns : [{
								header : '类    别',
								align : 'center',
								dataIndex : 'text'
							}, {
								header : '内    容',
								align : 'center',
								dataIndex : 'value'
							}]
				});

		var deds = new Ext.data.SimpleStore({
					fields : ['text', 'value'],
					data : [["学号", record.json.sid],
							["中文名", record.json.cname],
							["韩文名", record.json.kname],
							["英文名", record.json.ename],
							["学科", record.json.study],
							["课程", record.json.course],
							["班级", record.json.iclass],
							["护照名", record.json.ename],
							["护照号", showUrl(record.data.pb_id)],
							["签证号", record.json.pb_type],
							["签证起始", record.json.pb_begin],
							["签证终止", record.json.pbtimeout],
							["生日", record.json.birthday],
							["图书证", record.json.memo]]
				});

		dgrid.setTitle(record.json.sid + '-' + record.json.cname + '-'
				+ record.json.kname);
		var imgel = Ext.getDom('stuphoto');
		if (imgel.src)
			imgel.src = photopath + '/photo/' + record.json.sid + '.jpg'
		dgrid.reconfigure(deds, cmde);
	}

	this.add(grid);
	// 第三、调整，tbar分页,工具栏

}
Ext.extend(zz.Office.PassmngPanel, Ext.Panel, {

});
