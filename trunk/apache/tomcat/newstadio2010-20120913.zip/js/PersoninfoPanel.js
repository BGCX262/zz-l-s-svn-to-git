
zz.Office.PersoninfoPanel = function(config) {
	zz.Office.PersoninfoPanel.superclass.constructor.call(this, config);

	// 加上服务器上的jsp数据生成

	var proxy = new Ext.data.HttpProxy({
				url : 'getstudentlist.do?tab=personinfo'
			});
	var recordType = new Ext.data.Record.create([{
				name : "id",
				type : "string"
			}, {
				name : "birthday",
				dateFormat : 'Y-m-d',
				type : "date"
			}, {
				name : "sex",
				type : "string"
			}, {
				name : "ename",
				type : "string"
			}, {
				name : "pass_id",
				type : "string"
			}, {
				name : "memo",
				type : "string"
			}, {
				name : "hasphoto",
				type : "string"
			}, {
				name : "sid",
				type : "string"
			}, {
				name : "iclass",
				type : "string"
			}, {
				name : "study",
				type : "string"
			}, {
				name : "cname",
				type : "string"
			}, {
				name : "kname",
				type : "string"
			}, {
				name : "subname",
				type : "string"
			}, {
				name : "result",
				type : "string"
			}, {
				name : "course",
				type : "string"
			}, {
				name : "pb_id",
				type : "string"
			}]);

	// 定义分析器
	var reader = new Ext.data.JsonReader({
				totalProperty : "results",
				root : "rows",
				id : "id"
			}, recordType);

	// 定义store
	var ds = new Ext.data.Store({
				id : 'dss_pi',
				proxy : proxy,
				reader : reader
			});
	this.ds = ds;
	ds.on('load', function() {
				var d = Ext.getCmp('cosmenu_pi');
				if (d.getText() != '全部') {
					ds.filter('course', d.getText());
				}
				putClassEl();
			});

	var delbtn = new zz.Util.ButtonSelectionModel({
				dataIndex : 'id',
				url : 'ModifyResult.do?edit=delstu&datecode='
						+ (new Date().getTime()),
				saveconfirm : 'saveconfirm_pi', // 增加属性saveconfirm，用于记录saveconfirm的id，作为是否允许删除标志
				align : 'left',
				// hidden : true,
				listeners : {
					'rowselect' : function(sm, row, rec) {
						setDetailsPanel(rec);
					}
				}
			});
	var cm = new Ext.grid.ColumnModel({
				defaultSortable : true,
				defaultWidth : 40,
				columns : [new Ext.grid.RowNumberer(), {
							header : '学号',
							editor : new Ext.form.NumberField({
										allowBlank : true
									}),
							dataIndex : 'sid'
						}, {
							header : '课程',
							editor : new Ext.form.ComboBox({
										store : new Ext.data.SimpleStore({
													fields : ['text'],
													data : [['基本课程'], ['深化课程'],
															['双学位课程'], ['未知']]
												}),
										mode : 'local',
										triggerAction : 'all',
										valueField : 'text',
										displayField : 'text',
										editable : false
									}),
							dataIndex : 'course'
						}, {
							header : '班级',
							editor : new Ext.form.TextField({// 暂时简单实现
									// allowBlank : true
									}),
							width : 15,
							dataIndex : 'iclass'
						}, {
							header : '中文名',
							editor : new Ext.form.TextField({
									// allowBlank : true
									}),
							dataIndex : 'cname'
						}, {
							header : '韩文名',
							editor : new Ext.form.TextField({
									// allowBlank : true
									}),
							dataIndex : 'kname'
						}, {
							header : '护照名',
							editor : new Ext.form.TextField({
									// allowBlank : true
									}),
							dataIndex : 'ename'
						}, {
							header : '护照号',
							editor : new Ext.form.TextField({
									// allowBlank : true
									}),
							dataIndex : 'pb_id'
						}, {
							header : '性别',
							width : 15,
							editor : new Ext.form.ComboBox({
										store : new Ext.data.SimpleStore({
													fields : ['text'],
													data : [['男'], ['女']]
												}),
										mode : 'local',
										triggerAction : 'all',
										valueField : 'text',
										displayField : 'text',
										editable : false
									}),
							dataIndex : 'sex'
						}/*
							 * , { header : '课目', editor : new
							 * Ext.form.ComboBox({ editable : false, //
							 * 添加科目在科目管理中实现 name : 'sub', store : dssub, mode :
							 * 'remote', triggerAction : 'all', valueField :
							 * 'text', displayField : 'view', editable : true,
							 * listeners : {} }), dataIndex : 'subname' }, {
							 * header : '入境日期', editor : new
							 * Ext.form.DateField({}), dataIndex : '' }
							 */, {
							header : '生日',
							editor : new Ext.form.DateField({format:'Y-m-d'}),
							renderer : Ext.util.Format.dateRenderer('Y-m-d'),
							dataIndex : 'birthday'
						}, {
							header : '学科',
							editor : new Ext.form.TextField({
									// allowBlank : true
									}),
							dataIndex : 'study'
						}, {
							header : '图书证',
							editor : new Ext.form.TextField({
									// allowBlank : true
									}),
							dataIndex : 'memo'
						}, {
							header : '结业证',
							editor : new Ext.form.TextField({
									// allowBlank : true
									}),
							hidden : true,
							dataIndex : 'pass_id'
						}, {
							header : '照片',
							hidden : true,
							editor : new Ext.form.ComboBox({
										store : new Ext.data.SimpleStore({
													fields : ['text', 'value'],
													data : [['有', 1], ['无', 0]]
												}),
										mode : 'local',
										triggerAction : 'all',
										valueField : 'value',
										displayField : 'text',
										editable : true
									}),
							dataIndex : 'hasphoto'
						}, delbtn]
			});
	var exportbtn = new Ext.Button({
	    text: '&nbsp;导出Excel',
	    iconCls : 'excel',
	    handler: function() {
	        var vExportContent = grid.getExcelXml();
	        if (Ext.isIE || Ext.isSafari || Ext.isSafari2 || Ext.isSafari3) {
	            var fd=Ext.get('frmDummy');
	            if (!fd) {
	                fd=Ext.DomHelper.append(Ext.getBody(),{tag:'form',method:'post',id:'frmDummy',action:'exportexcel.jsp', target:'_blank',name:'frmDummy',cls:'x-hidden',cn:[
	                    {tag:'input',name:'exportContent',id:'exportContent',type:'hidden'}
	                ]},true);
	            }
	            fd.child('#exportContent').set({value:vExportContent});
	            fd.dom.submit();
	        } else {
	            document.location = 'data:application/vnd.ms-excel;base64,'+Base64.encode(vExportContent);
	        }}
	});
			
	var mytoolbar = new Ext.Toolbar([
			'',
			{
				id : 'cosmenu_pi',
				text : '全部',
				iconCls : 'im16x16',
				handler : function() {
					// putClassEl();
					if (!(this.text == '全部'))
						putClassEl();
					ds.clearFilter();
					fliterOptation(this.text, '全部班级');
				},
				xtype : 'splitbutton',
				menu : new Ext.menu.Menu({
							items : [{
								text : '全部',
								iconCls : 'im16x16',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_pi').text);
									Ext.getCmp('cosmenu_pi').setText(this.text);
								}
							}, {
								text : '基本课程',
								iconCls : 'user-kid',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_pi').text);
									Ext.getCmp('cosmenu_pi').setText(this.text);
								}
							}, {
								text : '深化课程',
								iconCls : 'user-suit',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_pi').text);
									Ext.getCmp('cosmenu_pi').setText(this.text);

								}
							}, {
								text : '双学位课程',
								iconCls : 'user-girl',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_pi').text);
									Ext.getCmp('cosmenu_pi').setText(this.text);

								}
							}]
						})

			},
			'',
			'-',
			'',
			{
				id : 'classel_pi',
				text : '全部班级',
				iconCls : 'im16x16',
				handler : function() {
					var fls = this.text;
					fliterOptation(Ext.getCmp('cosmenu_pi').text, this.text);
				},
				xtype : 'splitbutton',
				menu : new Ext.menu.Menu({
							items : null
						}),
				listeners : {}
			},
			'',
			'-',
			'',
			'<img src=pic/s.gif style="background:url(images/find_user_icon.gif); width:16px" />',
			{
				width : 80,
				id : 'sidquery_pi',
				xtype : 'numberfield',
				emptyText : '输入学号...',
				// enableKeyEvents : true,
				listeners : {
					'blur' : function(el) {
						el.setValue('');
					},
					'render' : function(el1) {
						// el1.setValue('');
						Ext.get('sidquery_pi').on('keypress', function(e, el) {
							var querystr = 'sid';
							var k = e.getKey();
							/**
							 * 每按键一次就筛选速度慢，改为只判断回车才筛选 if (k > 47 && k < 131 || k >
							 * 127 || k == 32) { e.stopEvent(); var key =
							 * String.fromCharCode(k); el.value = el.value !=
							 * null ? el.value + key : key;
							 * 
							 * ds.clearFilter() ds.filterBy(function(record) {
							 * var b = Ext.getCmp('cosmenu_pi').text
							 * .indexOf('全部') >= 0 ? true :
							 * Ext.getCmp('cosmenu_pi').text == record
							 * .get('course'); b &=
							 * Ext.getCmp('classel_pi').text .indexOf('全部') >= 0 ?
							 * true : Ext.getCmp('classel_pi').text == record
							 * .get('iclass'); return b && record.get(querystr)
							 * .indexOf(el.value) > -1 }); } else
							 */
							if (k == 13) {
								ds.clearFilter()
								ds.filterBy(function(record) {
									var b = Ext.getCmp('cosmenu_pi').text
											.indexOf('全部') >= 0
											? true
											: Ext.getCmp('cosmenu_pi').text == record
													.get('course');
									b &= Ext.getCmp('classel_pi').text
											.indexOf('全部') >= 0
											? true
											: Ext.getCmp('classel_pi').text == record
													.get('iclass');
									return b
											&& record.get(querystr)
													.indexOf(el.value) > -1
								});
							}
						});

					}
				}
			}, '->',exportbtn,'', '-', '', {
				text : '添加记录',
				id : 'xiangqing_pi',
				tooltip : '添加记录',
				iconCls : 'add',
				handler : function() {
					var dt = new Date();
					Ext.Msg.prompt('', '请输入添加学生的学号：', function(btn, text) {
						if (btn == 'ok' && text.length == 8
								&& parseInt(text) > 20000000) {
							Ext.Ajax.request({
								url : 'ModifyResult.do?edit=perinfoedit&datecode='
										+ (new Date().getTime()),
								params : {
									submitData : Ext.util.JSON.encode([{
												'sid' : text
											}])
								},
								success : function(e, h) {
									// alert("保存已成功。");
									ds.reload();
									ds.filterBy(function(record) { // 有问题，无法筛选到
												var b = text == record
														.get('sid');
												return b;
											});
								},
								failure : function() {
									alert('添加失败!');
								}
									// scope : storeObj
							});
						} else if (btn == 'ok')
							alert("学号不合法的！")
					});
					// var record = Ext.data.Record.create([
					// {}]);
					// new Ext.data.Record(); //新建一条记录，id时间戳
					// record.set('id',dt.format('U'));
					// record.set('cos','未知');
					// record.set('text',null);
					// ds.add(record);
				}
			}, '', '-', '', {
				id : 'saveconfirm_pi',
				text : '编辑选项',
				width : 80,
				handler : null,
				xtype : 'splitbutton',
				menu : new Ext.menu.Menu({
					items : [{
								text : '修改前需确认',
								handler : function() {
									grid.on("afteredit", function(e) {
												saveBtnHandler(null, e)
												return false; // 阻止事件继续传播
											}, grid);
									Ext.getCmp('saveconfirm_pi')
											.setText(this.text);
									Ext.getCmp('saveconfirm_pi').handler = null;
								}
							}, {
								text : '不提示直接修改',
								handler : function() {
									grid.on("afteredit", function(e) {
												saveBtnHandler(null, e)
												return false;
											}, grid);
									Ext.getCmp('saveconfirm_pi')
											.setText(this.text);
									Ext.getCmp('saveconfirm_pi').handler = null;
								}
							}, {
								text : '修改后统一提交',
								handler : function() {
									grid.un("afteredit", function(e) {
												saveBtnHandler(null, e)
												return false;
											}, grid); // 取消grid编辑后的提交动作
									Ext.getCmp('saveconfirm_pi')
											.setText(this.text);
									Ext.getCmp('saveconfirm_pi').handler = saveBtnHandler;
								}
							}]
				})
				// arrowHandler: function(){Ext.MessageBox.alert("","ooo")}
			}]);
	// mytoolbar end

	var pagingBar = new Ext.PagingToolbar({
				disabled : true,
				pageSize : 10000,
				store : ds,
				displayInfo : true,
				displayMsg : '共有 {2}条记录',
				// hidden : true,
				emptyMsg : "没有数据"
			});

	var grid = new Ext.grid.EditorGridPanel({
				id : 'datagrid_pi',
				cm : cm,
				store : ds,
				// width : 660,
				// height : 600,
				region : "center",
				margins : '2 2 2 2',
				selModel : delbtn,
				bbar : pagingBar,
				stripeRows : true ,				
				viewConfig : {
				               forceFit : true,
				               getRowClass : function(record,rowIndex,rowParams,store){
				                   //签证快到期的红色显示
				               		var s = record.json.pb_begin!=null && record.json.pb_out!=null && record.json.pbtimeout!=null 
				               		? record.json.pbtimeout.replace(/-/g,"/") : null;
				               		var d = s != null ?Date.parse(s) : null;
				               		var to = 20*24*3600*1000;	//20天
				                   if(d!=null && (d-new Date().getTime())<to){
				                       return 'x-grid-record-red';
				                   }else{
				                       return '';
				                   }     
				               }
				},
				loadMask : {
					msg : '正在载入数据,请稍等...'
				},
				// title : '公司列表',
				tbar : mytoolbar,
				listeners : {
					'render' : function(el) {
						// grid.on("afteredit", function(e) {
						// saveBtnHandler(null, e);
						// }, grid);
					},
					'beforerender' : function(gd) {
						// debugger;
					}
				}
			});

	function remoteQuery(cosname, classname, subjectstr) {
		// 查询远程数据，要求返回相关全部数据，即在subject上选课与未选课的人
		// ,即若无人选课，应能得到全部人名单
		ds.load({
					params : {
						subname : subjectstr
					}
				});
	}

	function fliterOptation(cosname, classname, subjectstr) {
		// 使用fliteby的处理函数，处理班级课程间过滤联动关系,
		// 因为是单科成绩表，所以联动需加入subcombo的值
		ds.clearFilter();
		ds.filterBy(function(re) {
					var b = true;
					// 不能显示没有选课的人，考虑吧课程查询作为触发远程查询
					if (cosname.indexOf('全部') >= 0) { // 
						return b;
					} else if (classname.indexOf('全部') >= 0) { // 筛选class时，要考虑course的筛选继续有效
						b &= re.get('course') == cosname;
					} else {
						b &= re.get('course') == cosname;
						b &= re.get('iclass') == classname;
					}
					if (!(Ext.isEmpty(subjectstr)))
						b &= re.get('subname') == subjectstr
								|| Ext.isEmpty(re.get('subname'));
					return b;
				});
	}

	function putClassEl() {
		// 从grid store中提取班级
		Ext.getCmp('classel_pi').menu.removeAll();
		Ext.getCmp('classel_pi').menu.add({
					text : '全部班级',
					iconCls : 'im16x16',
					handler : function() {
						var s = this.text;
						fliterOptation(Ext.getCmp('cosmenu_pi').text, this.text);
						Ext.getCmp('classel_pi').setText(this.text);
					}
				});
		Ext.getCmp('classel_pi').setText('全部班级');
		var sz = '|';
		ds.data.each(function(re) {
					if (re.get('course') != Ext.getCmp('cosmenu_pi').getText())
						return;
					var c = re.get('iclass');
					if (c && c != '' && c != '-') {
						if (sz.indexOf('|' + c + '|') < 0) { // sz like
							// '|1-2|2-1|3-5|'
							sz += c + '|';
							var newclass = new Ext.menu.Item({
										text : c,
										iconCls : 'user-girl',
										handler : function() {
											fliterOptation(
													Ext.getCmp('cosmenu_pi').text,
													this.text);
											Ext.getCmp('classel_pi').setText(c);
										}
									});
							var m = Ext.getCmp('classel_pi').menu;
							// debugger
							m.add(newclass);
						}

					}
				});
		// 班级结束
	}

	/**
	 * 先修改，一次性提交 btn-提交按钮控件 e-当逐条提交修改时的编辑事件，含当前record等 ***********************
	 */
	function saveBtnHandler(btn, e) {
		var a = Ext.getCmp('saveconfirm_pi');
		if (a.text != '不提示直接修改' && a.text != '修改前需确认' && a.text != '修改后统一提交')
			return;
		else if (a.text == '修改后统一提交' && !btn) // 当为'修改后统一提交'时不响应afertrowedit事件
			return;

		var storeObj = ds;
		var modifiedRecords = storeObj.getModifiedRecords();
		var submitRecords = [];

		for (var i = 0, len = modifiedRecords.length; i < len; i++) {
			// 原型语句 submitRecords.push(storeObj.isWithAllFields === true ?
			// modifiedRecords[i].data : modifiedRecords[i].modified); //
			// 获取Record之中的实体数据
			if (modifiedRecords[i].data.sid) {
				submitRecords.push({
							id : modifiedRecords[i].json.id,
							sid : modifiedRecords[i].data.sid,
							course : modifiedRecords[i].data.course,
							/*
							 * subname : modifiedRecords[i].data.subname ?
							 * modifiedRecords[i].data.subname :
							 * Ext.getCmp('subcombo_pi').getValue(),
							 */
							birthday : modifiedRecords[i].data.birthday ? modifiedRecords[i].data.birthday.format('Y-m-d'):'null',
							sex : modifiedRecords[i].data.sex,
							pb_id : modifiedRecords[i].data.pb_id,
							pass_id : modifiedRecords[i].data.pass_id,
							kname : modifiedRecords[i].data.kname,
							cname : modifiedRecords[i].data.cname,
							study : modifiedRecords[i].data.study,
							ename : modifiedRecords[i].data.ename,
							hasphoto : modifiedRecords[i].data.hasphoto,
							memo : modifiedRecords[i].data.memo,
							iclass : modifiedRecords[i].data.iclass
						});
			}
		}
		if (submitRecords.length <= 0)
			return;
		if (a.text != '修改后统一提交') { // 只有当前记录被修改
			if (modifiedRecords.length > 1) {
				if (confirm('有陈旧修改数据，按“确定”清理数据重新输入，或“取消”后修改选项为“统一提交”！'))
					storeObj.commitChanges();
				storeObj.reload();
				return;
			} else {
				if (a.text == '不提示直接修改' || confirm('数据修改将被提交，是否继续？'))
					Ext.Ajax.request({
						url : 'ModifyResult.do?edit=perinfoedit&datecode='
								+ (new Date().getTime()),
						params : {
							submitData : Ext.util.JSON.encode(submitRecords)
						},
						success : function() {
							// alert("保存已成功。");
							storeObj.commitChanges();
						},
						failure : function() {
							alert('你的改变未能正常保存成功!');
						}
							// scope : storeObj
						});
			}

		} else { // 统一提交
			if (submitRecords.length == 0) {
				alert('没有发现修改过的记录，没有内容提交！');
				return;
			}

			// debugger
			btn.disable();
			if (confirm("您确定要进行该操作？") == true) {
				// 正在保存改变，请等待...
				Ext.Ajax.request({
					url : 'ModifyResult.do?edit=perinfoedit&datecode='
							+ (new Date().getTime()),
					params : {
						submitData : Ext.util.JSON.encode(submitRecords)
					},
					success : function() {
						alert("保存已成功。");
						storeObj.commitChanges();
						if (btn)
							btn.enable();
					},
					failure : function() {
						alert('你的改变未能正常保存成功!');
						if (btn)
							btn.enable();
					}
						// scope : storeObj
					});
			} else {
				btn.enable();
			}
		}
	}
	/** 修改结束 *********************** */

	function setDetailsPanel(record) {
		var dgrid = Ext.getCmp('detailsgrid');
		var cmde = new Ext.grid.ColumnModel({
					defaultWidth : 50,
					columns : [{
								header : '类    别',
								align : 'center',
								dataIndex : 'text'
							}, {
								header : '内    容',
								align : 'center',
								dataIndex : 'value'
							}]
				});
		// var outday = "";
		// if(record.json.pb_begin && record.json.pb_out)
		// outday = new Date((new
		// Date(Date.parse(record.json.pb_begin.replace(/-/g,
		// "/")))).getTime()+parseInt(record.json.pb_out)*24*3600*1000);

		/**
	 * 显示护照影印件
	 */
	function  showUrl(value){
		return "<a href='pbimg.jsp?pbid="+value+"' target='_blank'>"+value+"</a>";
	}
	
		var deds = new Ext.data.SimpleStore({
					fields : ['text', 'value'],
					data : [["学号", record.json.sid],
							["中文名", record.json.cname],
							["韩文名", record.json.kname],
							["英文名", record.json.ename],
							["学科", record.json.study],
							["课程", record.json.course],
							["班级", record.json.iclass],
							["护照名", record.json.ename],
							["护照号", showUrl(record.data.pb_id)],
							["签证号", record.json.pb_type],
							["签证起始", record.json.pb_begin],
							["签证终止", record.json.pbtimeout],
							["生日", record.json.birthday],
							["图书证", record.json.memo]]
				});

		dgrid.setTitle(record.json.sid + '-' + record.json.cname + '-'
				+ record.json.kname);
		var imgel = Ext.getDom('stuphoto');
		if (imgel.src)
			imgel.src = photopath + '/photo/' + record.json.sid
					+ '.jpg'
		dgrid.reconfigure(deds, cmde);
	}

	this.add(grid);
	// 第三、调整，tbar分页,工具栏

}
Ext.extend(zz.Office.PersoninfoPanel, Ext.Panel, {

});
