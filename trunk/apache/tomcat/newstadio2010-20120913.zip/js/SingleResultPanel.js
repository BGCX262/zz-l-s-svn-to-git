// 显示单科成绩
// zz.Office.unconfirm = false; // 设置全局变量unconfirm，在修改grid数据时用于判断是否提示

/**
 * 构造grid中的按钮组件zz.Util.ButtonSelectionModel
 * 
 * @param {}
 *            config
 */
zz.Util.ButtonSelectionModel = Ext.extend(Ext.grid.RowSelectionModel, {
			header : '<div class="zz-grid-delbtn">&#160;</div>',
			width : 40,
			align : 'center',
			sortable : false,

			// private
			menuDisabled : true,
			fixed : true,
			hideable : false,
			dataIndex : '',
			id : 'deleter',
			url : '',
			saveconfirm :'saveconfirm_pi',		//增加属性saveconfirm，用于记录saveconfirm的id，作为是否允许删除标志

			deleteAll : function() {		//危险操作，等权限管理后再实现
				alert('危险操作，等权限管理完成后再实现');
			},

			deleteThis : function(st, delid) {
				var a = Ext.getCmp(this.saveconfirm);
				if (a.text=='编辑选项' || !confirm('真的要删除本记录吗？'))
					return;
				Ext.Ajax.request({
							url : this.url,
							params : {
								id : delid
							},
							success : function() {
								st.reload();
							},
							failure : function() {
								alert('删除失败!');
							}
						});
			},

			constructor : function() {
				zz.Util.ButtonSelectionModel.superclass.constructor.apply(this,
						arguments);

				if (this.checkOnly) {
					this.handleMouseDown = Ext.emptyFn;
				}
			},

			// private
			initEvents : function() {
				zz.Util.ButtonSelectionModel.superclass.initEvents.call(this);
				this.grid.on('render', function() {
							var view = this.grid.getView();
							view.mainBody.on('mousedown', this.onMouseDown,
									this);
							Ext.fly(view.innerHd).on('mousedown',
									this.onHdMouseDown, this);

						}, this);
			},

			// If handleMouseDown was called from another event
			// (enableDragDrop), set a flag so
			// onMouseDown does not process it a second time
			handleMouseDown : function() {
				zz.Util.ButtonSelectionModel.superclass.handleMouseDown.apply(
						this, arguments);
				this.mouseHandled = true;
			},

			// private
			onMouseDown : function(e, t) {
				if (e.button === 0 && t.className == 'zz-grid-delbtn') { // Only
																			// fire
																			// if
																			// left-click
					e.stopEvent();
					var row = e.getTarget('.x-grid3-row');

					// mouseHandled flag check for a duplicate selection
					// (handleMouseDown) call
					if (!this.mouseHandled && row) {
						var index = row.rowIndex;
						var st = this.grid.store;
						this
								.deleteThis(st, st.getAt(index)
												.get(this.dataIndex));
					}
				}
				this.mouseHandled = false;
			},

			// private
			onHdMouseDown : function(e, t) {
				if (t.className == 'zz-grid-delbtn') {
					e.stopEvent();
					var hd = Ext.fly(t.parentNode);
					// var isChecked = hd.hasClass('x-grid3-hd-checker-on');
					// if(isChecked){
					// hd.removeClass('x-grid3-hd-checker-on');
					// this.clearSelections();
					// }else{
					// hd.addClass('x-grid3-hd-checker-on');
					this.deleteAll();
					// }
				}
			},

			// private
			renderer : function(v, p, record) {
				return record.get(this.dataIndex) == null
						|| record.get(this.dataIndex) == ''
						? ''
						: '<div class="zz-grid-delbtn">&#160;</div>';
			}
		});
/** *zz.Util.ButtonSelectionModel结束** */

/**
 * zz.Office.SingleresultPanel开始，呈现单科成绩页面
 * 
 * @param {}
 *            config
 */
zz.Office.SingleresultPanel = function(config) {
	zz.Office.SingleresultPanel.superclass.constructor.call(this, config);

	// 加上服务器上的jsp数据生成

	var proxy = new Ext.data.HttpProxy({
				url : 'getstudentlist.do?tab=singleresult'
			});

	var recordType = new Ext.data.Record.create([{
				name : "id",
				type : "string"
			}, {
				name : "sid",
				type : "string"
			}, {
				name : "iclass",
				type : "string"
			}, {
				name : "cname",
				type : "string"
			}, {
				name : "kname",
				type : "string"
			}, {
				name : "subname",
				type : "string"
			}, {
				name : "result",
				type : "string"
			}, {
				name : "course",
				type : "string"
			}, {
				name : "pb_id",
				type : "string"
			}]);

	// 定义分析器
	var reader = new Ext.data.JsonReader({
				totalProperty : "results",
				root : "rows",
				id : "id"
			}, recordType);

	// 定义store
	var ds = new Ext.data.Store({
				id : 'dss_sr',
				proxy : proxy,
				reader : reader
			});
	this.ds = ds;
	ds.on('load', function() {
		var d = Ext.getCmp('cosmenu_sr');
		ds.filter('course', d.getText());
		putClassEl();
			// dssub.load();
		});

	var dssub = new Ext.data.JsonStore({
				fields : ['cos', 'text', 'view'],
				url : 'getlist.do?par=sub_cmbo&cos=all&datecode=' + (new Date().getTime()),
				root : 'root',
				sortInfo : {
					field : "cos",
					direction : "DESC"
				}
			});
	dssub.on('load', function(elstore) {
		elstore.each(function(r) {
			r.set('view', r.get('text')); // r.set('view',
				// r.get('text') + '-' +
				// r.get('cos'));
			});
			/*******************************************************************
			 * 页面呈现时过滤课程******** var record =
			 * elstore.getAt(elstore.find('text','汉语',0,true)>=0?elstore.find('text','汉语',0,true):0);
			 * Ext.getCmp('subcombo').setValue(record.get('text'));
			 * remoteQuery(Ext.getCmp('cosmenu').text,Ext.getCmp('classel').text,record.get('text'));
			 ******************************************************************/
			// remoteQuery(Ext.getCmp('cosmenu').text,Ext.getCmp('classel').text,null);
		});
	// dssub.load( );
	/***************************************************************************
	 * ***********************************************改用从grid的store里提取 var dssub =
	 * new Ext.data.SimpleStore({ fields : ['text'], sortInfo : { field :
	 * 'text', direction : 'DESC' } });
	 **************************************************************************/

	var delbtn = new zz.Util.ButtonSelectionModel({
				saveconfirm : 'saveconfirm_sr',		//增加属性saveconfirm，用于记录saveconfirm的id，作为是否允许删除标志
				dataIndex : 'id',
				url : 'ModifyResult.do?edit=delresult&datecode=' + (new Date().getTime()),
				width: 200,
				align : 'left',
				listeners : {
					'rowselect' : function(sm, row, rec) {
						setDetailsPanel(rec);
					}
				}
			});
	var cm = new Ext.grid.ColumnModel({
				defaultSortable : true,
				defaultWidth : 40,
				columns : [new Ext.grid.RowNumberer(), {
							header : '学号',
							dataIndex : 'sid'
						}, {
							header : '中文名',
							dataIndex : 'cname'
						}, {
							header : '韩文名',
							// width : 300,
							dataIndex : 'kname'
						}, {
							header : '课程',
							// width : 300,
							dataIndex : 'course'
						}, {
							header : '班级',
							// width : 300,
							dataIndex : 'iclass'
						}, {
							header : '课目',
							editor : new Ext.form.ComboBox({
										editable : false, // 添加科目在科目管理中实现
										name : 'sub',
										store : dssub,
										mode : 'remote',
										triggerAction : 'all',
										valueField : 'text',
										displayField : 'view',
										editable : true,
										listeners : {}
									}),
							dataIndex : 'subname'
						}, {
							header : '成绩',
							editor : new Ext.form.NumberField({
										allowBlank : true
									}),
							dataIndex : 'result'
						}, delbtn]
			});

	var exportbtn = new Ext.Button({
	    text: '&nbsp;导出Excel',
	    iconCls : 'option',
	    handler: function() {
	        var vExportContent = grid.getExcelXml();
	        if (Ext.isIE || Ext.isSafari || Ext.isSafari2 || Ext.isSafari3) {
	            var fd=Ext.get('frmDummy');
	            if (!fd) {
	                fd=Ext.DomHelper.append(Ext.getBody(),{tag:'form',method:'post',id:'frmDummy',action:'exportexcel.jsp', target:'_blank',name:'frmDummy',cls:'x-hidden',cn:[
	                    {tag:'input',name:'exportContent',id:'exportContent',type:'hidden'}
	                ]},true);
	            }
	            fd.child('#exportContent').set({value:vExportContent});
	            fd.dom.submit();
	        } else {
	            document.location = 'data:application/vnd.ms-excel;base64,'+Base64.encode(vExportContent);
	        }}
	});
			
	var mytoolbar = new Ext.Toolbar([
			'',
			{
				id : 'cosmenu_sr',
				text : '基本课程',
				iconCls : 'im16x16',
				handler : function() {
					// putClassEl();
					if (!(this.text == '全部'))
						putClassEl();
					ds.clearFilter();
					fliterOptation(this.text, '全部');// ,
													// Ext.getCmp('subcombo_sr').getValue());
				},
				xtype : 'splitbutton',
				menu : new Ext.menu.Menu({
							items : [{
								text : '基本课程',
								iconCls : 'user-kid',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_sr').text,
											Ext.getCmp('subcombo_sr')
													.getValue());
									Ext.getCmp('cosmenu_sr').setText(this.text);
								}
							}, {
								text : '深化课程',
								iconCls : 'user-suit',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_sr').text,
											Ext.getCmp('subcombo_sr')
													.getValue());
									Ext.getCmp('cosmenu_sr').setText(this.text);

								}
							}, {
								text : '双学位课程',
								iconCls : 'user-girl',
								handler : function() {
									putClassEl();
									// ds.filter("course", this.text)
									fliterOptation(this.text, Ext
													.getCmp('classel_sr').text,
											Ext.getCmp('subcombo_sr')
													.getValue());
									Ext.getCmp('cosmenu_sr').setText(this.text);

								}
							}]
						})

			},
			'',
			'-',
			'',
			{
				id : 'classel_sr',
				text : '全部班级',
				iconCls : 'im16x16',
				handler : function() {
					var fls = this.text;
					fliterOptation(Ext.getCmp('cosmenu_sr').text, this.text);
				},
				xtype : 'splitbutton',
				menu : new Ext.menu.Menu({
							items : null
						}),
				listeners : {}
			},
			'',
			'-',
			'',
			'<img src=pic/s.gif style="background:url(images/find_user_icon.gif); width:16px" />',
			{
				width : 80,
				id : 'sidquery_sr',
				xtype : 'numberfield',
				emptyText : '输入学号...',
				// enableKeyEvents : true,
				listeners : {
					'blur' : function(el) {
						el.setValue('');
					},
					'render' : function(el1) {
						// el1.setValue('');
						Ext.get('sidquery_sr').on('keypress', function(e, el) {
							var querystr = 'sid';
							var k = e.getKey();
							/**每按键一次就筛选速度慢，改为只判断回车才筛选
							 * if (k > 47 && k < 131 || k > 127 || k == 32) {
								e.stopEvent();
								var key = String.fromCharCode(k);
								el.value = el.value != null
										? el.value + key
										: key;

								ds.clearFilter()
								ds.filterBy(function(record) {
									var b = Ext.getCmp('cosmenu_sr').text
											.indexOf('全部') >= 0
											? true
											: Ext.getCmp('cosmenu_sr').text == record
													.get('course');
									b &= Ext.getCmp('classel_sr').text
											.indexOf('全部') >= 0
											? true
											: Ext.getCmp('classel_sr').text == record
													.get('iclass');
									return b
											&& record.get(querystr)
													.indexOf(el.value) > -1
								});
							} else*/ if (k == 13) {
								ds.clearFilter()
								ds.filterBy(function(record) {
									var b = Ext.getCmp('cosmenu_sr').text
											.indexOf('全部') >= 0
											? true
											: Ext.getCmp('cosmenu_sr').text == record
													.get('course');
									b &= Ext.getCmp('classel_sr').text
											.indexOf('全部') >= 0
											? true
											: Ext.getCmp('classel_sr').text == record
													.get('iclass');
									return b
											&& record.get(querystr)
													.indexOf(el.value) > -1
								});
							}
						});

					}
				}
			},
			'->',exportbtn,'', '-', '',
			'<img src=pic/s.gif style="background:url(images/subject.png); width:16px" />',
			'', {
				name : 'subcheck',
				id : 'subcombo_sr',
				store : dssub,
				xtype : 'combo',
				mode : 'remote',
				width : 120,
				triggerAction : 'all',
				// pageSize : 5, // 未实现分页，希望能按课程分页，第一页是当前cosname
				resizable : true,
				valueField : 'text',
				displayField : 'view',
				editable : true,
				listeners : {
					'select' : function(combo, record) {
						remoteQuery(Ext.getCmp('cosmenu_sr').text, Ext
										.getCmp('classel_sr').text, record
										.get('text'));
						// fliterOptation(Ext.getCmp('cosmenu').text,
						// Ext.getCmp('classel').text, record.get('text') );
					}
				}
			}, '', '-', '', {
				id : 'saveconfirm_sr',
				text : '编辑选项',
				width : 80,
				handler : null,
				xtype : 'splitbutton',
				menu : new Ext.menu.Menu({
					items : [{
								text : '修改前需确认',
								handler : function() {
									grid.on("afteredit", function(e) {
												saveBtnHandler(null, e)
											}, grid);
									Ext.getCmp('saveconfirm_sr')
											.setText(this.text);
									Ext.getCmp('saveconfirm_sr').handler = null;
								}
							}, {
								text : '不提示直接修改',
								handler : function() {
									grid.on("afteredit", function(e) {
												saveBtnHandler(null, e)
											}, grid);
									Ext.getCmp('saveconfirm_sr')
											.setText(this.text);
									Ext.getCmp('saveconfirm_sr').handler = null;
								}
							}, {
								text : '修改后统一提交',
								handler : function() {
									grid.un("afteredit", function(e) {
												saveBtnHandler(null, e)
											}, grid); // 取消grid编辑后的提交动作
									Ext.getCmp('saveconfirm_sr')
											.setText(this.text);
									Ext.getCmp('saveconfirm_sr').handler = saveBtnHandler;
								}
							}]
				})
				// arrowHandler: function(){Ext.MessageBox.alert("","ooo")}
			}]);
	// mytoolbar end

	var pagingBar = new Ext.PagingToolbar({
				disabled : true,
				pageSize : 10000,
				store : ds,
				displayInfo : true,
				displayMsg : '共有 {2}条记录',
				// hidden : true,
				emptyMsg : "没有数据"
			});

	var grid = new Ext.grid.EditorGridPanel({
				id : 'datagrid_sr',
				cm : cm,
				store : ds,
				// width : 660,
				// height : 600,
				region : "center",
				margins : '2 2 2 2',
				bbar : pagingBar,stripeRows : true ,
				viewConfig : {
					forceFit : true
				},
				loadMask : {
					msg : '正在载入数据,请稍等...'
				},
				// title : '公司列表',
				selModel : delbtn,
				tbar : mytoolbar,
				listeners : {
					'render' : function(el) {
						grid.on("afteredit", function(e) {
									saveBtnHandler(null, e);
								}, grid);
					},
					'beforerender' : function(gd) {
						// debugger;
					}
				}
			});

	function fillsubnamestore(store1) { // 从gridstore中提取subname填充到相应store中（dssub）
		var gridstoredata = ds.data;
		if (ds.isFiltered()) // 过滤后data无法得到全部，snapshot是data原始的备份
			gridstoredata = ds.snapshot;
		if (gridstoredata) {
			store1.removeAll();
			// 新增

			gridstoredata.each(function(re) {
						var s = re.get('subname');
						if (s) {
							if (store1.find('text', s) < 0) {
								var newRecord1 = new Array();
								newRecord1['text'] = s;
								store1.add(new Ext.data.Record(newRecord1));
							}
						}
					});
			// debugger
		}

	}

	function remoteQuery(cosname, classname, subjectstr) {
		// 查询远程数据，要求返回相关全部数据，即在subject上选课与未选课的人
		// ,即若无人选课，应能得到全部人名单
		//ds.url = 'getstudentlist.do?datecode='+ (new Date().getTime());
		ds.load({
					params : {
						subname : subjectstr,
						datecod : new Date().getTime()
					}
				});
	}

	function fliterOptation(cosname, classname, subjectstr) {
		// 使用fliteby的处理函数，处理班级课程间过滤联动关系,
		// 因为是单科成绩表，所以联动需加入subcombo的值
		ds.clearFilter();
		ds.filterBy(function(re) {
					var b = true;
					// 不能显示没有选课的人，考虑吧课程查询作为触发远程查询
					if (cosname.indexOf('全部') >= 0) { // 
						return b;
					} else if (classname.indexOf('全部') >= 0) { // 筛选class时，要考虑course的筛选继续有效
						b &= re.get('course') == cosname;
					} else {
						b &= re.get('course') == cosname;
						b &= re.get('iclass') == classname;
					}
					if (!(Ext.isEmpty(subjectstr)))
						b &= re.get('subname') == subjectstr
								|| Ext.isEmpty(re.get('subname'));
					return b;
				});
	}

	function putClassEl() {
		// 从grid store中提取班级
		Ext.getCmp('classel_sr').menu.removeAll();
		Ext.getCmp('classel_sr').menu.add({
					text : '全部班级',
					iconCls : 'im16x16',
					handler : function() {
						var s = this.text;
						Ext.getCmp('subcombo_sr').setValue("");
						fliterOptation(Ext.getCmp('cosmenu_sr').text, this.text);
						Ext.getCmp('classel_sr').setText(this.text);
					}
				});
		Ext.getCmp('classel_sr').setText('全部班级');
		var sz = '|';
		ds.data.each(function(re) {
					// if(re.get('course') != Ext.getCmp('cosmenu').getText())
					// return;
					var c = re.get('iclass');
					if (c && c != '' && c != '-') {
						if (sz.indexOf('|' + c + '|') < 0) { // sz like
							// '|1-2|2-1|3-5|'
							sz += c + '|';
							var newclass = new Ext.menu.Item({
										text : c,
										iconCls : 'user-girl',
										handler : function() {
											fliterOptation(
													Ext.getCmp('cosmenu_sr').text,
													this.text);
											Ext.getCmp('classel_sr').setText(c);
										}
									});
							var m = Ext.getCmp('classel_sr').menu;
							// debugger
							m.add(newclass);
						}

					}
				});
		// 班级结束
	}

	/**
	 * 先修改，一次性提交 btn-提交按钮控件 e-当逐条提交修改时的编辑事件，含当前record等 ***********************
	 */
	function saveBtnHandler(btn, e) {
		var a = Ext.getCmp('saveconfirm_sr');
		if (a.text != '不提示直接修改' && a.text != '修改前需确认' && a.text != '修改后统一提交')
			return;
		else if (a.text == '修改后统一提交' && !btn) // 当为'修改后统一提交'时不响应afertrowedit事件
			return;

		var storeObj = ds;
		var modifiedRecords = storeObj.getModifiedRecords();
		var submitRecords = [];

		for (var i = 0, len = modifiedRecords.length; i < len; i++) {
			// 原型语句 submitRecords.push(storeObj.isWithAllFields === true ?
			// modifiedRecords[i].data : modifiedRecords[i].modified); //
			// 获取Record之中的实体数据
			if (modifiedRecords[i].data.result
					&& (modifiedRecords[i].data.subname != '' || Ext
							.getCmp('subcombo_sr').getValue())) {
				submitRecords.push({
							id : modifiedRecords[i].json.id,
							sid : modifiedRecords[i].json.sid,
							course : modifiedRecords[i].json.course,
							subname : modifiedRecords[i].data.subname
									? modifiedRecords[i].data.subname
									: Ext.getCmp('subcombo_sr').getValue(),
							result : modifiedRecords[i].data.result
						});
			}
		}
		if (submitRecords.length <= 0)
			return;
		if (a.text != '修改后统一提交') { // 只有当前记录被修改
			if (modifiedRecords.length > 1) {
				if (confirm('有陈旧修改数据，按“确定”清理数据重新输入，或“取消”后修改选项为“统一提交”！'))
					storeObj.commitChanges();
					storeObj.reload();
				return;
			} else {
				if (a.text == '不提示直接修改' || confirm('数据修改将被提交，是否继续？'))
					Ext.Ajax.request({
						url : 'ModifyResult.do?edit=result&datecode=' + (new Date().getTime()),
						params : {
							submitData : Ext.util.JSON.encode(submitRecords)
						},
						success : function() {
							alert("保存已成功。");
							storeObj.commitChanges();
						},
						failure : function() {
							alert('你的改变未能正常保存成功!');
						}
							// scope : storeObj
						});
			}

		} else { // 统一提交
			if (submitRecords.length == 0) {
				alert('没有发现修改过的记录，没有内容提交！');
				return;
			}

			// debugger
			btn.disable();
			if (confirm("您确定要进行该操作？") == true) {
				// 正在保存改变，请等待...
				Ext.Ajax.request({
					url : 'ModifyResult.do?edit=result&datecode=' + (new Date().getTime()),
					params : {
						submitData : Ext.util.JSON.encode(submitRecords)
					},
					success : function() {
						alert("保存已成功。");
						storeObj.commitChanges();
						if (btn)
							btn.enable();
					},
					failure : function() {
						alert('你的改变未能正常保存成功!');
						if (btn)
							btn.enable();
					}
						// scope : storeObj
					});
			} else {
				btn.enable();
			}
		}
	}
	/** 修改结束 *********************** */

	function setDetailsPanel(record) {
		var dgrid = Ext.getCmp('detailsgrid');
		var cmde = new Ext.grid.ColumnModel({
					defaultWidth : 50,
					columns : [{
								header : '类    别',
								align : 'center',
								dataIndex : 'text'
							}, {
								header : '内    容',
								align : 'center',
								dataIndex : 'value'
							}]
				});

		var deds = new Ext.data.SimpleStore({
					fields : ['text', 'value'],
					data : [["学号", record.json.sid],
							["中文名", record.json.cname],
							["韩文名", record.json.kname],
							["英文名", record.json.ename],
							["学科", record.json.study],
							["课程", record.json.course],
							["班级", record.json.iclass],
							["护照名", record.json.pb_id]]
				});

		dgrid.setTitle(record.json.sid + '-' + record.json.cname + '-'
				+ record.json.kname);
		var imgel = Ext.getDom('stuphoto');
		if (imgel.src)
			imgel.src =  photopath + '/photo/' + record.json.sid
					+ '.jpg'
		dgrid.reconfigure(deds, cmde);
	}

	this.add(grid);
	// 第三、调整，tbar分页,工具栏

}
Ext.extend(zz.Office.SingleresultPanel, Ext.Panel, {

});
