//管理科目
//zz.Office.unconfirm = false;                // 设置全局变量unconfirm，在修改grid数据时用于判断是否提示

zz.Office.SubjectmngPanel = function(config) {
	zz.Office.SubjectmngPanel.superclass.constructor.call(this, config);

	var proxy = new Ext.data.HttpProxy({
		url : 'getlist.do?par=sub_cmbo&cos=all'
	});

	var recordType = new Ext.data.Record.create([{
				name : "sub_id",
				type : "string"
			}, {
				name : "cos",
				type : "string"
			}, {
				name : "text",
				type : "string"
			}, {
				name : "credits",
				type : "string"
			}]);

	// 定义分析器
	var reader = new Ext.data.JsonReader({
				totalProperty : "course",
				root : "root",
				id : "sub_id"
			}, recordType);

	// 定义store
	var dssub = new Ext.data.GroupingStore({
				id : 'dssubid',
				proxy : proxy,
				sortInfo : {
					field : 'text',
					direction : "ASC"
				},
				groupField : 'cos',
				reader : reader
			});
	this.ds = dssub;
	dssub.on('load', function() {
				var d = Ext.getCmp('cosmenu_sm');
				if (this.text === '全部')
					dssub.clearFilter();
				else
					dssub.filter("cos", this.text)
			});
	//var sm = new Ext.grid.CheckboxSelectionModel();
	var cm = new Ext.grid.ColumnModel({
		defaultSortable : true,
		defaultWidth : 150,
		columns : [{
					header : '课目',
					id: 'subcombo_sm',
					editor : new Ext.form.TextField({
								//allowBlank : true
							}),
					align : 'center',
					dataIndex : 'text'
				},{
					header : '学分',
					id : 'creditstb_sm',
					editor : new Ext.form.NumberField({
								allowBlank : true
							}),
					align : 'center',
					dataIndex : 'credits'
				}, {
					header : '课程',
					editor : new Ext.form.ComboBox({
								store : new Ext.data.SimpleStore({
											fields : ['text'],
											data : [['基本课程'], ['深化课程'],
													['双学位课程'], ['未知']]
										}),
								mode : 'local',
								triggerAction : 'all',
								valueField : 'text',
								displayField : 'text',
								editable : false
							}),
					align : 'center',
					dataIndex : 'cos'
				}, {
					header : '<input type="checkbox" id="checkall_sm"  onclick="checkAllFunc()">&nbsp;&nbsp;全选</input>',
					sortable : false,
					// align : 'center',
					dataIndex : 'sub_id',
					width : 1000,
					renderer : function(v) {
						return String.format(
								'<input type="checkbox" name=checkbox1 id="'
										+ v + '"></input>', id);
					}
				}]
	});
	
	var exportbtn = new Ext.Button({
	    text: '&nbsp;导出Excel',
	    iconCls : 'option',
	    iconCls : 'option',
	    handler: function() {
	        var vExportContent = grid.getExcelXml();
	        if (Ext.isIE || Ext.isSafari || Ext.isSafari2 || Ext.isSafari3) {
	            var fd=Ext.get('frmDummy');
	            if (!fd) {
	                fd=Ext.DomHelper.append(Ext.getBody(),{tag:'form',method:'post',id:'frmDummy',action:'exportexcel.jsp', target:'_blank',name:'frmDummy',cls:'x-hidden',cn:[
	                    {tag:'input',name:'exportContent',id:'exportContent',type:'hidden'}
	                ]},true);
	            }
	            fd.child('#exportContent').set({value:vExportContent});
	            fd.dom.submit();
	        } else {
	            document.location = 'data:application/vnd.ms-excel;base64,'+Base64.encode(vExportContent);
	        }}
	});
			
	var grid = new Ext.grid.EditorGridPanel({
		id : 'datagrid_sm',
		cm : cm,
		store : dssub,
		region : "center",
		margins : '2 2 2 2',
		bbar : pagingBar,
		viewConfig : new Ext.grid.GroupingView({
			startCollapsed : false,
			forceFit : true
			}),
		loadMask : {
			msg : '正在载入数据,请稍等...'
		},
		//title : '公司列表',
		selModel : new Ext.grid.RowSelectionModel({
					singleSelect : true
				}),
		tbar : ['', {
			id : 'cosmenu_sm',
			text : '全部',
			iconCls : 'im16x16',
			handler : function() {
				if (this.text === '全部')
					dssub.clearFilter();
				else
					dssub.filter("cos", this.text)
				//putClassEl();
			},
			xtype : 'splitbutton',
			menu : new Ext.menu.Menu({
						items : [{
									text : '全部',
									iconCls : 'user-kid',
									handler : function() {
										if (this.text === '全部')
											dssub.clearFilter();
										else
											dssub.filter("cos", this.text)
										Ext.getCmp('cosmenu_sm')
												.setText(this.text);
										//putClassEl();
									}
								}, {
									text : '基本课程',
									iconCls : 'user-kid',
									handler : function() {
										dssub.filter("cos", this.text)
										Ext.getCmp('cosmenu_sm')
												.setText(this.text);
										//putClassEl();
									}
								}, {
									text : '深化课程',
									iconCls : 'user-suit',
									handler : function() {
										dssub.filter("cos", this.text)
										Ext.getCmp('cosmenu_sm')
												.setText(this.text);
										//putClassEl();
									}
								}, {
									text : '双学位课程',
									iconCls : 'user-girl',
									handler : function() {
										dssub.filter("cos", this.text)
										Ext.getCmp('cosmenu_sm')
												.setText(this.text);
										//putClassEl();
									}
								}]
					})

		}, '->',exportbtn,'', '-', '', {
			text : '添加新课目',
			id : 'xiangqing_sm',
			tooltip : '添加新课目',
			iconCls : 'add',
			handler : function() {
					var dt = new Date();
					var record = dssub.getAt(0).copy(); //拷贝一条记录，id为null
					record.set('sub_id',dt.format('U'));
					record.set('cos','未知');
					record.set('text',null);
					dssub.add(record);
			}
		}, '-', {
			text : '删除选定课目',
			tooltip : '删除选定课目',
			iconCls : 'remove',
			handler : function() {
				// 取得选中记录（Record 类型）
				var rdids = new Array();
				var chs = document.getElementsByName('checkbox1');
				Ext.each(chs, function(ch) {
							if (ch.checked)
								rdids.push(ch.id);
						});
				if (rdids.length <= 0) {
					alert("请先选择要删除的行!");
					return;
				}
				if (rdids.length
						&& confirm('你真的要删除所选' + rdids.length + '条课目吗?')) {
					// 向后台发送请求，执行删除操作
					Ext.Ajax.request({
								url : 'ModifyResult.do?edit=delsubject&datecode=' + (new Date().getTime()),
								params : {
									id : rdids.toString()
								},
								success : function() {
									dssub.reload();
								},
								failure : function() {
									alert('删除失败');
								}
							});
				}
			}
		}, '-', {
			id : 'saveconfirm_sm',
			text : '编辑选项',
			width : 80,
			handler : null,
			xtype : 'splitbutton',
			menu : new Ext.menu.Menu({
				items : [{
								text : '修改前需确认',
								handler : function() {
									grid.on("afteredit", function(e) {
												saveBtnHandler(null, e)
											}, grid);
									Ext.getCmp('saveconfirm_sm')
											.setText(this.text);
									Ext.getCmp('saveconfirm_sm').handler = null;
								}
							}, {
								text : '不提示直接修改',
								handler : function() {
									grid.on("afteredit", function(e) {
												saveBtnHandler(null, e)
											}, grid);
									Ext.getCmp('saveconfirm_sm')
											.setText(this.text);
									Ext.getCmp('saveconfirm_sm').handler = null;
								}
							}, {
								text : '修改后统一提交',
								handler : function() {
									grid.un("afteredit", function(e) {
												saveBtnHandler(null, e)
											}, grid); // 取消grid编辑后的提交动作
									Ext.getCmp('saveconfirm_sm')
											.setText(this.text);
									Ext.getCmp('saveconfirm_sm').handler = saveBtnHandler;
								}
							}]
			})
				// arrowHandler: function(){Ext.MessageBox.alert("","ooo")}
		}]
	});

	var pagingBar = new Ext.PagingToolbar({
				disabled : true,
				pageSize : 10000,
				store : dssub,
				displayInfo : true,
				displayMsg : '共有 {2}条记录',
				//hidden : true,
				emptyMsg : "没有数据"
			});

	/*function fillsubnamestore(store1) { //从gridstore中提取subname填充到相应store中（dssub）
		var gridstoredata = dssub.data;
		if (dssub.isFiltered()) // 过滤后data无法得到全部，snapshot是data原始的备份
			gridstoredata = dssub.snapshot;
		if (gridstoredata) {
			store1.removeAll();
			// 新增

			gridstoredata.each(function(re) {
						var s = re.get('subname');
						if (s) {
							if (store1.find('text', s) < 0) {
								var newRecord1 = new Array();
								newRecord1['text'] = s;
								store1.add(new Ext.data.Record(newRecord1));
							}
						}
					});
			// debugger
		}

	}*/

	/**************************/
	/**
	 * 先修改，一次性提交 btn-提交按钮控件 e-当逐条提交修改时的编辑事件，含当前record等 ***********************
	 */
	function saveBtnHandler(btn, e) {
		var a = Ext.getCmp('saveconfirm_sm');
		if (a.text != '不提示直接修改' && a.text != '修改前需确认' && a.text != '修改后统一提交')
			return;
		else if (a.text == '修改后统一提交' && !btn) // 当为'修改后统一提交'时不响应afertrowedit事件,标志是btn为null
			return;

		var storeObj = dssub;
		var modifiedRecords = storeObj.getModifiedRecords();
		var submitRecords = [];

		for (var i = 0, len = modifiedRecords.length; i < len; i++) {
			// 原型语句 submitRecords.push(storeObj.isWithAllFields === true ?
			// modifiedRecords[i].data : modifiedRecords[i].modified); //
			// 获取Record之中的实体数据

			if (modifiedRecords[i].data.text
					&& modifiedRecords[i].data.text != '' ) {
				submitRecords.push({
							sub_id : modifiedRecords[i].data.sub_id		//id为空可能是新数据，用时间戳代替
									? modifiedRecords[i].data.sub_id
									: (new Date().getTime()),
							subname : modifiedRecords[i].data.text
									? modifiedRecords[i].data.text
									: Ext.getCmp('subcombo_sm').getValue(),
							credits : modifiedRecords[i].data.credits? 
										modifiedRecords[i].data.credits
									: Ext.getCmp('creditstb_sm').getValue(),
							course : modifiedRecords[i].data.cos
						});
			}
		}
		if (submitRecords.length <= 0)
			return;
		if (a.text != '修改后统一提交') { // 只有当前记录被修改
			if (modifiedRecords.length > 1) {
				if (confirm('有陈旧修改数据，按“确定”清理数据重新输入，或“取消”后修改选项为“统一提交”！'))
					storeObj.commitChanges();
					storeObj.reload();
				return;
			} else {
				if (a.text == '不提示直接修改' || confirm('数据修改将被提交，是否继续？'))
					Ext.Ajax.request({
						url : 'ModifyResult.do?edit=submng&datecode=' + (new Date().getTime()),
						params : {
							submitData : Ext.util.JSON.encode(submitRecords)
						},
						success : function() {
							if (a.text == '修改后统一提交')
								alert("保存已成功。");
							storeObj.commitChanges();
						},
						failure : function() {
							alert('你的改变未能正常保存成功!');
						}
							// scope : storeObj
						});
			}

		} else { // 统一提交
			if (submitRecords.length == 0) {
				alert('没有发现修改过的记录，没有内容提交！');
				return;
			}

			// debugger
			btn.disable();
			if (confirm("您确定要进行该操作？") == true) {
				// 正在保存改变，请等待...
				Ext.Ajax.request({
					url : 'ModifyResult.do?edit=submng&datecode=' + (new Date().getTime()),
					params : {
						submitData : Ext.util.JSON.encode(submitRecords)
					},
					success : function() {
						alert("保存已成功。");
						storeObj.commitChanges();
						if (btn)
							btn.enable();
					},
					failure : function() {
						alert('你的改变未能正常保存成功!');
						if (btn)
							btn.enable();
					}
						// scope : storeObj
					});
			} else {
				btn.enable();
			}
		}
	}
	/** 修改结束 *********************** */

	this.add(grid);
	// 第三、调整，tbar分页,工具栏

}
Ext.extend(zz.Office.SubjectmngPanel, Ext.Panel, {});
function checkAllFunc() {
	var ca = document.getElementById("checkall_sm");
	var ids = document.getElementsByName("checkbox1");
	for (var i = 0; i < ids.length; i++) {
		ids[i].checked = ca.checked;
	}
}
