var iPicNum = 5;	//图片总数量
        function Step1() {
            $("#Step2Container").hide();           
        }

        function Step2() {
        	//$("#Step2Container").show();
            $("#CurruntPicContainer").hide();
        }
        function Step3() {
            $("#Step2Container").hide();          
       }
        
        /////////////////////////
		function checkCoords()
		{
			if (parseInt($('#txt_width').val()))
				if ($('#pbid') && $('#pbid').val().trid()!="")
					return true;
				else
					alert('护照号码为空！')
			else
				alert('请剪裁后再提交！');
			return false;
		};
		
		
		$(window).load(function() {
			var scaleFactor = 2;	//设置缩小倍率
			
			$('#cropbox').Jcrop({	//初始化jcrop
				//aspectRatio: 2,
				onSelect: function(c){	//增加scaleFactor倍率
					$('#txt_left').val(c.x * scaleFactor);
					$('#txt_top').val(c.y * scaleFactor);
					$('#txt_DropWidth').val(c.w * scaleFactor);
					$('#txt_DropHeight').val(c.h * scaleFactor);
				}
			});

		    var $iconElement = $("#cropbox");
		    
		    //获取上传图片的实际高度，宽度
		    var image = new Image();
		    image.src = $iconElement.attr("src");
		    var realWidth = image.width;
		    var realHeight = image.height;  
		    image = null;       

		    //图片实际尺寸，并近似到整数
		    var currentWidth = Math.round(realWidth / scaleFactor);
		    var currentHeight = Math.round(realHeight / scaleFactor);


		    //图片相对CANVAS的初始位置，图片相对画布居中
		    var originLeft = 0 ;
		    var originTop = 0;

		    //设置图片当前尺寸和位置
		    $iconElement.css({ width: currentWidth + "px", height: currentHeight + "px", left: originLeft + "px", top: originTop + "px" });

		    //初始化默认值
		    $("#txt_width").val(realWidth);
		    $("#txt_height").val(realHeight);

		    //设置小图点击显示
		    $(".imgphoto").click(function(){
		    	alert("asd");
		    	$(".fullphoto").src=this.src;
		    	$(".fullphoto").show();
		    });

		});
		
$(function(){
	for(var i=1;i<=iPicNum;i++)
		//添加图片的缩略图
		//$(document.body).append($("<div class='thumb pt'><a href='#'><img src='/pbimg/"+i.toString()+".jpg'></a></div>"));
	$("div:has(a)").addClass("thumb");
	for(var i=0;i<=iPicNum;i++){
		var myimg = new Image();
		myimg.src = $("div a img").get(i).src;
		//根据图片的比例（水平或者竖直），添加不同的样式
		if(myimg.width > myimg.height)
			$("div:has(a):eq("+i+")").addClass("ls");
		else
			$("div:has(a):eq("+i+")").addClass("pt");
	}
	
	$("#showPhoto").hide();	//初始化时不显示大图
	$("#bgblack").css("opacity",0.9);	//显示大图的方块背景设置为透明
	
	$("#close").click(function(){
		//点击按钮close，则关闭大图面板（采用动画）
		$("#showPhoto").add("#showPic").fadeOut(400);
	});
	
	$("div a:has(img)").click(function(){
		//如果点击缩略图，则显示大图
		$("#showPhoto").css({
			//大图的位置根据窗口来判断
			"left":($(window).width()/2-300>20?$(window).width()/2-300:20),
			"top":($(window).height()/2-270>30?$(window).height()/2-270:30)
		}).add("#showPic").fadeIn(400);
		//根据缩略图的地址，获取相应的大图地址
		var mySrc = $(this).find("img").attr("src");
		mySrc = "photo" + mySrc.slice(mySrc.lastIndexOf("/"));
		$("#showPic").find("img").attr("src",mySrc);
		
		if($(this).parent().hasClass("ls"))
			//根据图片属性（水平或者竖直），调整大图的位置
			$("#showPic").find("img").css("marginTop","70px");
		else if($(this).parent().hasClass("pt"))
			$("#showPic").find("img").css("marginTop","0px");
	});

	var currentSrc;
	var bMargin;
	$("#prev").click(function(){
		//点击“上一幅”按钮
		currentSrc = $("#showPic").find("img").attr("src");
		//根据目前的地址，获取上一幅的地址
		var iNum = parseInt(currentSrc.substring(currentSrc.lastIndexOf("/")+1,currentSrc.lastIndexOf(".jpg")));
		var iPrev = (iNum == 1)?iPicNum:(iNum-1);
		var prevSrc = "photo/" + iPrev.toString() + ".jpg";
		$("#showPic").find("img").attr("src",prevSrc);
		
		bMargin = $("div:has(img[src$=/"+iPrev.toString()+".jpg])").hasClass("ls");
		//根据图片对应的缩略图属性（水平或者竖直），调整大图的位置
		if(bMargin)
			$("#showPic").find("img").css("marginTop","70px");
		else
			$("#showPic").find("img").css("marginTop","0px");
	});
	
	$("#next").click(function(){
		//点击“下一幅”按钮
		currentSrc = $("#showPic").find("img").attr("src");
		var iNum = parseInt(currentSrc.substring(currentSrc.lastIndexOf("/")+1,currentSrc.lastIndexOf(".jpg")));
		var iNext = (iNum == iPicNum)?1:iNum+1;
		var nextSrc = "photo/" + iNext.toString() + ".jpg";
		$("#showPic").find("img").attr("src",nextSrc);
		
		bMargin = $("div:has(img[src$=/"+iNext.toString()+".jpg])").hasClass("ls");
		if(bMargin)
			$("#showPic").find("img").css("marginTop","70px");
		else
			$("#showPic").find("img").css("marginTop","0px");
	});
	
	$("#showPic").find("img").click(function(){
		//点击大图，同样显示下一幅
		$("#next").click();
	});
});